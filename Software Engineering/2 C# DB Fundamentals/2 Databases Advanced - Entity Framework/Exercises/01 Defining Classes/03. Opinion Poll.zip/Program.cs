﻿using System;
using System.Collections.Generic;
using System.Linq;
class Program
{
    static void Main(string[] args)
    {
        var n = int.Parse(Console.ReadLine());
        var listOfPersons = new List<Person>();
        for (int i = 0; i < n; i++)
        {
            var tokens = Console.ReadLine().Split().ToArray();
            var name = tokens[0];
            var age = int.Parse(tokens[1]);
            var person = new Person(name, age);
            listOfPersons.Add(person);
        }
        var sortedPersons = listOfPersons.Where(p => p.Age > 30).OrderBy(p => p.Name);
        foreach (var person in sortedPersons)
            Console.WriteLine($"{person.Name} - {person.Age}");
    }
}
