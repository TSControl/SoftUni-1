﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
public class Program
{
    static void Main(string[] args)
    {
        var n = int.Parse(Console.ReadLine());
        var listOfEmployees = new List<Employee>();
        for (int i = 0; i < n; i++)
        {
            var tokens = Console.ReadLine().Split();
            var name = tokens[0];
            var salary = double.Parse(tokens[1]);
            var position = tokens[2];
            var department = tokens[3];
            var employee = new Employee(name, salary, position, department);
            if (tokens.Count() == 5)
            {
                var isInt = int.TryParse(tokens[4], out int age);
                if (isInt == false)
                    employee.Email = tokens[4];
                else
                    employee.Age = age; //=int.Parse(tokens[4])
            }
            else if (tokens.Count() == 6)
            {
                var email = tokens[4];
                var age = int.Parse(tokens[5]);
                employee.Email = email;
                employee.Age = age;
            }
            listOfEmployees.Add(employee);
        }
        var dicDepartments = new Dictionary<string, List<double>>();
        foreach (var employee in listOfEmployees)
        {
            var department = employee.Department;
            var salary = employee.Salary;
            if (!dicDepartments.ContainsKey(department))
                dicDepartments.Add(department, new List<double>() { salary });
            else
                dicDepartments.First(d => d.Key == department).Value.Add(salary);
        }
        var topKvp = dicDepartments.OrderBy(kvp => -kvp.Value.Average()).First();
        var topDepartment = topKvp.Key;
        Console.WriteLine($"Highest Average Salary: {topDepartment}");
        foreach (var employee in listOfEmployees.Where(e => e.Department == topDepartment).OrderBy(e => -e.Salary))
        {
            Console.WriteLine($"{employee.Name} {employee.Salary:F2} {employee.Email} {employee.Age}");
        }
    }
}
