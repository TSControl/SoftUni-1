﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
public class Car
{
    public string Model { get; set; }
    public double FuelAmount { get; set; }
    public double FuelConsumption { get; set; }
    public double DistanceTraveled { get; set; }
    public Car()
    {
        this.DistanceTraveled = 0;
    }
    public Car(string model, int fuelAmount, double fuelConsumption)
    {
        this.Model = model;
        this.FuelAmount = fuelAmount;
        this.FuelConsumption = fuelConsumption;
        this.DistanceTraveled = 0;
    }
    public void Travel (int distanceToTravel)
    {
        var maxDistance = this.FuelAmount / this.FuelConsumption;
        if (distanceToTravel <= maxDistance)
        {
            this.FuelAmount -= this.FuelConsumption * distanceToTravel;
            this.DistanceTraveled += distanceToTravel;
        }
        else
        {
            Console.WriteLine("Insufficient fuel for the drive");
        }

    }
}