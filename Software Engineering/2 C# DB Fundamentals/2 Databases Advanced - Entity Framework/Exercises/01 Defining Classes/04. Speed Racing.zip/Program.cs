﻿using System;
using System.Collections.Generic;
using System.Linq;
public class Program
{
    static void Main(string[] args)
    {
        var n = int.Parse(Console.ReadLine());
        var listOfCars = new List<Car>();
        for (int i = 0; i < n; i++)
        {
            var tokens = Console.ReadLine().Split().ToArray();
            var model = tokens[0];
            //check unique model
            if (listOfCars.Any(c => c.Model == model))
                continue;
            var fuelAmount = int.Parse(tokens[1]);
            var fuelConsumption = double.Parse(tokens[2]);
            //add car
            var car = new Car(model, fuelAmount, fuelConsumption);
            listOfCars.Add(car);
        }
        string input = "";
        while ((input = Console.ReadLine()) != "End")
        {
            var tokens = input.Split().ToArray();
            var model = tokens[1];
            var distanceToTravel = int.Parse(tokens[2]);
            //try to travel
            var currentCar = listOfCars.First(c => c.Model == model);
            currentCar.Travel(distanceToTravel);
        }
        foreach (var car in listOfCars)
            Console.WriteLine($"{car.Model} {car.FuelAmount:F2} {car.DistanceTraveled:F0}");
    }
}