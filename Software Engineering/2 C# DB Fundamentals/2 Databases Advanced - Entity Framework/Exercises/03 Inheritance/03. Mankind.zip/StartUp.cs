﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class StartUp
{
    static void Main(string[] args)
    {
        var tokensS = Console.ReadLine().Split();
        var tokensW = Console.ReadLine().Split();
        var firstNameS = tokensS[0];
        var secondNameS = tokensS[1];
        var facNum = tokensS[2];
        var firstNameW = tokensW[0];
        var secondNameW = tokensW[1];
        var weeklySalary = decimal.Parse(tokensW[2]);
        var workingHours = decimal.Parse(tokensW[3]);
        try
        {
            var student = new Student(firstNameS, secondNameS, facNum);
            var worker = new Worker(firstNameW, secondNameW, weeklySalary, workingHours);
            Console.WriteLine(student);
            Console.WriteLine();
            Console.WriteLine(worker);
        }
        catch (ArgumentException ae)
        {
            Console.WriteLine(ae.Message);
        }
    }
}
