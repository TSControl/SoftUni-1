﻿using System;
using System.Collections.Generic;
using System.Linq;

public class StartUp
{
    static void Main(string[] args)
    {
        var listOfPeople = new List<Person>();
        var listOfProducts = new List<Product>();

        //fill list of people
        var peopleCash = Console.ReadLine().Split(";=".ToCharArray()).ToArray();
        for (int i = 0; i < peopleCash.Length; i += 2)
        {
            var personName = peopleCash[i];
            var personBalance = decimal.Parse(peopleCash[i + 1]);
            try
            {
                var person = new Person(personName, personBalance);
                listOfPeople.Add(person);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return;
            }
        }

        //fill list of products
        var productsPrices = Console.ReadLine().Split(";=".ToCharArray()).ToArray();
        for (int i = 0; i < productsPrices.Length; i += 2)
        {
            try
            {
                var productName = productsPrices[i];
                var productPrice = decimal.Parse(productsPrices[i + 1]);
                var product = new Product(productName, productPrice);
                listOfProducts.Add(product);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return;
            }
        }

        //cycle till END
        var input = "";
        while ((input = Console.ReadLine()) != "END")
        {
            var tokens = input.Split().ToArray();
            var personName = tokens[0];
            var productName = tokens[1];
            var person = listOfPeople.First(p => p.Name == personName);
            var product = listOfProducts.First(p => p.Name == productName);
            if (person.Money >= product.Price)
            {
                person.Money -= product.Price;
                person.BagOfProducts.Add(product);
                Console.WriteLine($"{person.Name} bought {product.Name}");
            }
            else
            {
                Console.WriteLine($"{person.Name} can't afford {product.Name}");
            }
        }

        //print all bought stuff
        foreach (var person in listOfPeople)
        {
            person.FinalOutput();
        }
    }
}

