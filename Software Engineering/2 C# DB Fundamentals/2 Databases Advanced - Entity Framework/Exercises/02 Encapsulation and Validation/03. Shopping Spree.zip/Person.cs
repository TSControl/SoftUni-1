﻿using System;
using System.Collections.Generic;

public class Person
{
    private string name;
    private decimal money;
    private List<Product> bagOfProducts;
    public Person(string name, decimal money)
    {
        this.Name = name;
        this.Money = money;
        this.BagOfProducts = new List<Product>();
    }
    public string Name
    {
        get { return name; }
        private set
        {
            if (value == "")
            {
                throw new Exception("Name cannot be empty");
            }
            else
            {
                name = value;
            }
        }
    }

    public decimal Money
    {
        get { return money; }
        set
        {
            if (value < 0)
            {
                throw new Exception("Money cannot be negative");
            }
            else
            {
                money = value;
            }
        }
    }

    public List<Product> BagOfProducts
    {
        get { return bagOfProducts; }
        private set { bagOfProducts = value; }
    }
    public void FinalOutput()
    {
        if (this.BagOfProducts.Count != 0)
        {
            Console.WriteLine($"{this.Name} - {string.Join(", ", bagOfProducts)}");
        }
        else
        {
            Console.WriteLine($"{this.Name} - Nothing bought");
        }
    }
}
