﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class Pizza
{
    private string name;
    private Dough dough;
    private List<Topping> toppings;
    public Pizza()
    {
        this.Toppings = new List<Topping>();
    }
    public Pizza(string name)
        :this()
    {
        this.Name = name;
    }
    public Pizza(string name, Dough dough)
        :this(name)
    {
        this.Dough = dough;
    }

    public string Name
    {
        get { return name; }
        private set
        {
            if (value.Length < 1 || value.Length > 15)
                throw new Exception("Pizza name should be between 1 and 15 symbols.");
            this.name = value;
        }
    }

    public Dough Dough
    {
        get { return this.dough; }
        set { dough = value; }
    }


    public List<Topping> Toppings { get; }

    public double TotalCalories()
    {
        return this.Dough.GetCalories() + this.Toppings.Select(t => t.GetCalories()).Sum();
    }

    public void AddTopping(Topping topping)
    {
        if (this.Toppings.Count >= 10)
            throw new Exception("Number of toppings should be in range [0..10].");
        this.Toppings.Add(topping);
    }
}

