﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class Dough
{
    private string flourType;
    private string bakingTechnique;
    private double weight;

    public Dough()
    {

    }
    public Dough(string flourType, string bakingTechnique, double weight)
    {
        this.FlourType = flourType;
        this.BakingTechnique = bakingTechnique;
        this.Weight = weight;
    }

    public string FlourType
    {
        get { return flourType; }
        private set
        {
            if (value.ToLower() != "white" && value.ToLower() != "wholegrain")
            {
                throw new Exception("Invalid type of dough.");
            }
                this.flourType = value;
        }
    }

    public string BakingTechnique
    {
        get { return bakingTechnique; }
        private set
        {
            if (!new string[] { "crispy", "chewy", "homemade" }.Contains(value.ToLower()))
            {
                throw new Exception("Invalid type of dough.");
            }
                this.bakingTechnique = value;
        }
    }

    public double Weight
    {
        get { return this.weight; }
        private set
        {
            if (value < 1 || value > 200)
            {
                throw new Exception("Dough weight should be in the range [1..200].");
            }
                weight = value;
        }
    }

    public double GetCalories()
    {
        var bakingTechniqueModifier = 1.0;
        var flourTypeModifier = 1.0;
        if (this.FlourType.ToLower() == "white")
            flourTypeModifier = 1.5;
        switch (BakingTechnique.ToLower())
        {
            case "crispy":
                bakingTechniqueModifier = 0.9;
                break;
            case "chewy":
                bakingTechniqueModifier = 1.1;
                break;
        }
        return 2 * this.Weight * bakingTechniqueModifier * flourTypeModifier;
    }
}

