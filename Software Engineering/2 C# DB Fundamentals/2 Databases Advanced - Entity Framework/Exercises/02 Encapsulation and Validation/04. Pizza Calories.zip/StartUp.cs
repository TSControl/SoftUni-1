﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class StartUp
{
    static void Main(string[] args)
    {
        var pizza = new Pizza();
        var dough = new Dough();
        var pizzaName = Console.ReadLine().Split()[1];

        try
        {
            pizza = new Pizza(pizzaName);
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
            return;
        }

        try
        {
            var doughTokens = Console.ReadLine().Split().ToArray();
            var doughFlourType = doughTokens[1];
            var doughBakingTechnique = doughTokens[2];
            var doughWeight = double.Parse(doughTokens[3]);
            dough = new Dough(doughFlourType, doughBakingTechnique, doughWeight);
            pizza.Dough = dough;
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
            return;
        }

        var toppingLine = "";
        while ((toppingLine = Console.ReadLine()) != "END")
        {
            try
            {
                var toppingTokens = toppingLine.Split().ToArray();
                var toppingType = toppingTokens[1];
                var toppingWeight = double.Parse(toppingTokens[2]);
                var topping = new Topping(toppingType, toppingWeight);
                pizza.AddTopping(topping);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return;
            }
        }
        Console.WriteLine($"{pizza.Name} - {pizza.TotalCalories():F2} Calories.");
    }
}
