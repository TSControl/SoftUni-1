﻿using System;
using System.Linq;
using System.Reflection;

public class StartUp
{
    static void Main(string[] args)
    {
        Type boxType = typeof(Box);
        FieldInfo[] fields = boxType.GetFields(BindingFlags.NonPublic | BindingFlags.Instance);
        Console.WriteLine(fields.Count());

        var box = new Box(double.Parse(Console.ReadLine()), double.Parse(Console.ReadLine()), double.Parse(Console.ReadLine()));
        Console.WriteLine($"Surface Area - {box.Area():F2}");
        Console.WriteLine($"Lateral Surface Area - {box.LateralArea():F2}");
        Console.WriteLine($"Volume - {box.Volume():F2}");
    }
}