﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Box
{
    private double length;
    private double width;
    private double height;
    public Box(double length, double width, double height)
    {
        this.Length = length;
        this.Width = width;
        this.Height = height;
    }
    private double Length
    {
        get { return length; }
        set { this.length = value; }
    }
    private double Width
    {
        get { return width; }
        set { this.width = value; }
    }
    private double Height
    {
        get { return height; }
        set { this.height = value; }
    }
    public double Area()
    {
        double result = 0d;
        result = 2 * (this.length * this.width + this.length * this.height + this.width * this.height);
        return result;
    }
    public double LateralArea()
    {
        double result = 0d;
        result = 2 * (this.length + this.width) * this.height;
        return result;
    }
    public double Volume()
    {
        double result = 0d;
        result = this.length * this.width * this.height;
        return result;
    }
}

