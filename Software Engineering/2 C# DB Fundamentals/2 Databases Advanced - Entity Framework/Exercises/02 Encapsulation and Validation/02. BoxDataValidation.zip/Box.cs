﻿using System;

public class Box
{
    private double length;
    private double width;
    private double height;
    public Box(double length, double width, double height)
    {
        this.Length = length;
        this.Width = width;
        this.Height = height;
    }

    public double Length
    {
        get { return this.length; }
        private set
        {
            if (value <= 0)
                throw new Exception("Length cannot be zero or negative.");
            else
                this.length = value;
        }
    }
    public double Width
    {
        get { return width; }
        private set
        {
            if (value <= 0)
                throw new Exception("Width cannot be zero or negative.");
            else
                this.width = value;
        }
    }
    public double Height
    {
        get { return height; }
        private set
        {
            if (value <= 0)
                throw new Exception("Height cannot be zero or negative.");
            else
                this.height = value;
        }
    }
    public double Area()
    {
        double result = 0d;
        result = 2 * (this.length * this.width + this.length * this.height + this.width * this.height);
        return result;
    }
    public double LateralArea()
    {
        double result = 0d;
        result = 2 * (this.length + this.width) * this.height;
        return result;
    }
    public double Volume()
    {
        double result = 0d;
        result = this.length * this.width * this.height;
        return result;
    }
}

