﻿using System;
public class DateModifier
{
    public int DaysDiff (string firstDate, string secondDate)
    {
        var date1 = DateTime.Parse(firstDate);
        var date2 = DateTime.Parse(secondDate);
        var daysDiff = (date2 - date1).Days;
        return daysDiff;
    }
}

