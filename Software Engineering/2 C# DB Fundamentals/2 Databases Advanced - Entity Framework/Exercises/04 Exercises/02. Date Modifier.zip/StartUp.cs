﻿using System;
public class StartUp
{
    static void Main(string[] args)
    {
        var date1 = Console.ReadLine();
        var date2 = Console.ReadLine();
        var dateModifier = new DateModifier();
        Console.WriteLine(Math.Abs(dateModifier.DaysDiff(date1, date2)));
    }
}