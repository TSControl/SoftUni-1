﻿namespace Problem6.ExceptionTree
{
    public class InvalidSongMinutesException : InvalidSongLengthException
    {
        public InvalidSongMinutesException()
            : base()
        {

        }

        public InvalidSongMinutesException(string message)
            : base(message)
        {

        }

        public InvalidSongMinutesException(int minMin, int minMax)
            : base($"Song minutes should be between {minMin} and {minMax}.")
        {

        }
    }
}
