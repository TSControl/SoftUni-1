﻿namespace Problem6.ExceptionTree
{
    public class InvalidSongSecondsException : InvalidSongLengthException
    {
        public InvalidSongSecondsException()
            : base()
        {

        }

        public InvalidSongSecondsException(string message)
            : base(message)
        {

        }

        public InvalidSongSecondsException(int secMin, int secMax)
            : base($"Song seconds should be between {secMin} and {secMax}.")
        {

        }
    }
}
