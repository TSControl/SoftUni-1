﻿namespace Problem6.Models
{
    using Problem6.ExceptionTree;

    public class Song
    {
        private const int ARTIST_NAME_MIN_LENGTH = 3;
        private const int ARTIST_NAME_MAX_LENGTH = 20;
        private const int SONG_NAME_MIN_LENGTH = 3;
        private const int SONG_NAME_MAX_LENGTH = 30;
        private const int MINUTES_MIN = 0;
        private const int MINUTES_MAX = 14;
        private const int SECONDS_MIN = 0;
        private const int SECONDS_MAX = 59;

        private string artistName;
        private string songName;
        private int minutes;
        private int seconds;

        public Song(string artistName, string songName, int minutes, int seconds)
        {
            this.ArtistName = artistName;
            this.SongName = songName;
            this.Minutes = minutes;
            this.Seconds = seconds;
        }

        private string ArtistName
        {
            set
            {
                if (value.Length < ARTIST_NAME_MIN_LENGTH || value.Length > ARTIST_NAME_MAX_LENGTH)
                {
                    throw new InvalidArtistNameException(ARTIST_NAME_MIN_LENGTH, ARTIST_NAME_MAX_LENGTH);
                }
                this.artistName = value;
            }
        }

        private string SongName
        {
            set
            {
                if (value.Length < SONG_NAME_MIN_LENGTH || value.Length > SONG_NAME_MAX_LENGTH)
                {
                    throw new InvalidSongNameException(SONG_NAME_MIN_LENGTH, SONG_NAME_MAX_LENGTH);
                }
                this.songName = value;
            }
        }

        public int Minutes
        {
            get { return minutes; }
            private set
            {
                if (value < MINUTES_MIN || value > MINUTES_MAX)
                {
                    throw new InvalidSongMinutesException(MINUTES_MIN, MINUTES_MAX);
                }
                this.minutes = value;
            }
        }

        public int Seconds
        {
            get { return seconds; }
            private set
            {
                if (value < SECONDS_MIN || value > SECONDS_MAX)
                {
                    throw new InvalidSongSecondsException(SECONDS_MIN, SECONDS_MAX);
                }
                seconds = value;
            }
        }
    }
}
