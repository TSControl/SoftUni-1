﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Tire
{
    private double pressure;
    private int age;

    public Tire(double pressure, int age)
    {
        this.pressure = pressure;
        this.age = age;
    }

    public int Age
    {
        get { return age; }
        set { age = value; }
    }


    public double Pressure
    {
        get { return pressure; }
        set { pressure = value; }
    }

}