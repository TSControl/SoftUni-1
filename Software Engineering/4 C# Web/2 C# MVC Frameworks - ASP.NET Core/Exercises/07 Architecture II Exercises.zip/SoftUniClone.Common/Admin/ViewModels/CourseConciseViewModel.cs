﻿namespace SoftUniClone.Common.Admin.ViewModels
{
    public class CourseConciseViewModel
    {
        public int Id { get; set; }

        public string Name { get; set; }
    }
}
