﻿namespace SoftUniClone.Services.Lecturer.Interfaces
{
    public interface ILecturerCourseInstancesService
    {
    }
}
