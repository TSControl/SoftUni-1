﻿using System;
using System.Collections.Generic;
using System.Linq;

class StartUp
{
	static void Main()
	{
		var citizensOrRebels = new List<IBuyer>();

		var n = int.Parse(Console.ReadLine());

		for (int i = 0; i < n; i++)
		{
			var tokens = Console.ReadLine().Split();

			var name = tokens[0];
			var age = int.Parse(tokens[1]);

			if (tokens.Length == 4)
			{
				var id = tokens[2];
				var birthday = tokens[3];

				var citizen = new Citizen(name, age, id, birthday);
				citizensOrRebels.Add(citizen);
			}
			else
			{
				var group = tokens[2];

				var rebel = new Rebel(name, age, group);
				citizensOrRebels.Add(rebel);
			}
		}

		string name1;
		while ((name1 = Console.ReadLine()) != "End")
		{
			if (citizensOrRebels.Any(c => c.Name == name1))
			{
				var citizenOrRebel = citizensOrRebels.FirstOrDefault(c => c.Name == name1);
				citizenOrRebel.BuyFood();
			}
		}

		var totalFood = citizensOrRebels.Sum(c => c.Food);
		Console.WriteLine(totalFood);
	}
}