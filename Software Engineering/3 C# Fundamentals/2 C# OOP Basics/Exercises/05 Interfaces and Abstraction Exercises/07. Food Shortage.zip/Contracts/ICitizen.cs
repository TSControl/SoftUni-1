﻿public interface ICitizen
{
	int Age { get; set; }
}
