﻿using System.Collections.Generic;
using System.Text;

public class Commando : SpecialisedSoldier, ICommando
{
	public Commando(int id, string firstName, string lastName, decimal salary, string corps, List<Mission> missions)
		:base(id, firstName, lastName, salary, corps)
	{
		this.Missions = missions;
	}

	public List<Mission> Missions { get; }

	public override string ToString()
	{
		var builder = new StringBuilder();

		builder.AppendLine(base.ToString());
		builder.AppendLine("Missions:");
		foreach (var mission in this.Missions)
		{
			builder.AppendLine($" {mission}");
		}

		return builder.ToString().Trim();
	}
}