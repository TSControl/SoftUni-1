﻿using System.Collections.Generic;
using System.Text;

public class LeutenantGeneral : Private, ILutenatGeneral
{
	public LeutenantGeneral(int id, string firstName, string lastName, decimal salary, List<Private> privates)
		:base(id, firstName, lastName, salary)
	{
		this.Privates = privates;
	}

	public List<Private> Privates { get; set; }

	public override string ToString()
	{
		var builder = new StringBuilder();

		builder.AppendLine(base.ToString());
		builder.AppendLine("Privates:");

		foreach (var private1 in this.Privates)
		{
			builder.AppendLine($"  {private1.ToString()}");
		}

		return builder.ToString().Trim();
	}
}