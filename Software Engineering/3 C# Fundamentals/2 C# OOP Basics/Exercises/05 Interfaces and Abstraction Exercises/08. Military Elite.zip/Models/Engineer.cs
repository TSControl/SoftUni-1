﻿using System.Collections.Generic;
using System.Text;

public class Engineer : SpecialisedSoldier, IEngineer
{
	public Engineer(int id, string firstName, string lastName, decimal salary, string corps, List<Repair> repairs)
		:base(id, firstName, lastName, salary, corps)
	{
		this.Repairs = repairs;
	}

	public List<Repair> Repairs { get; }

	public override string ToString()
	{
		var builder = new StringBuilder();

		builder.AppendLine(base.ToString());
		builder.AppendLine("Repairs:");

		foreach (var repair in this.Repairs)
		{
			builder.AppendLine($"  {repair.ToString()}");
		}

		return builder.ToString().Trim();
	}
}