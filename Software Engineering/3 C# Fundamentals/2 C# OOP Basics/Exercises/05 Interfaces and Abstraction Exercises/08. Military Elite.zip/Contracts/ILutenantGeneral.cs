﻿using System.Collections.Generic;

public interface ILutenatGeneral : IPrivate
{
	List<Private> Privates { get; }
}