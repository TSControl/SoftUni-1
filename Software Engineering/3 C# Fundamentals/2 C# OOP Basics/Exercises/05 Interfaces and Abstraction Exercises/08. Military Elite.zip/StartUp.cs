﻿using System;
using System.Collections.Generic;
using System.Linq;

class StartUp
{
	static void Main()
	{
		var soldiers = new List<ISoldier>();

		string line;
		while ((line = Console.ReadLine()) != "End")
		{
			var lineSplit = line.Split();

			var soldierType = lineSplit[0];
			var id = int.Parse(lineSplit[1]);
			var firstName = lineSplit[2];
			var lastName = lineSplit[3];

			switch (soldierType)
			{
				case "Private":

					var salary = decimal.Parse(lineSplit[4]);
					var newPrivate = new Private(id, firstName, lastName, salary);
					soldiers.Add(newPrivate);

					break;

				case "LeutenantGeneral":

					var lGSalary = decimal.Parse(lineSplit[4]);

					var privates = new List<Private>();

					for (int i = 5; i < lineSplit.Length; i++)
					{
						var privateId = int.Parse(lineSplit[i]);

						Private privateToAdd = (Private)soldiers.Where(s => s.Id == privateId).Where(p => p.GetType().Name == "Private").FirstOrDefault();

						privates.Add(privateToAdd);
					}

					var leutenantGeneral = new LeutenantGeneral(id, firstName, lastName, lGSalary, privates);

					soldiers.Add(leutenantGeneral);

					break;

				case "Engineer":

					var eSalary = decimal.Parse(lineSplit[4]);
					var corps = lineSplit[5];

					var numberOfRepairs = (lineSplit.Length - 5) / 2;

					var repairs = new List<Repair>();

					for (int i = 0; i < numberOfRepairs; i++)
					{
						var part = lineSplit[6 + 2 * i];
						var hours = int.Parse(lineSplit[7 + 2 * i]);

						var repair = new Repair(part, hours);

						repairs.Add(repair);
					}
					try
					{
						var engineer = new Engineer(id, firstName, lastName, eSalary, corps, repairs);
						soldiers.Add(engineer);
					}
					catch (ArgumentException e)
					{

					}

					break;
				case "Commando":

					var cSalary = decimal.Parse(lineSplit[4]);
					var cCorps = lineSplit[5];

					var commandoNumberOfMissions = (lineSplit.Length - 5) / 2;

					var missions = new List<Mission>();
					for (int i = 0; i < commandoNumberOfMissions; i++)
					{
						var missionCodeName = lineSplit[6 + 2 * i];
						var missionState = lineSplit[7 + 2 * i];
						try
						{
							var mission = new Mission(missionCodeName, missionState);
							missions.Add(mission);
						}
						catch (ArgumentException ae)
						{

						}
					}

					try
					{
						var commando = new Commando(id, firstName, lastName, cSalary, cCorps, missions);
						soldiers.Add(commando);

					}
					catch (ArgumentException ae)
					{

					}

					break;
				case "Spy":

					var codeNumber = int.Parse(lineSplit[4]);

					var spy = new Spy(id, firstName, lastName, codeNumber);
					soldiers.Add(spy);

					break;
			}
		}

		foreach (var soldier in soldiers)
		{
			Console.WriteLine(soldier.ToString());
		}
	}
}