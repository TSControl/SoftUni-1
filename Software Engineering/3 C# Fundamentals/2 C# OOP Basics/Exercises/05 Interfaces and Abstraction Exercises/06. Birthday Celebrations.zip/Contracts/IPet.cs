﻿public interface IPet : ICitizenOrPet
{
	string Name { get; set; }
}