﻿public interface ICitizenOrPet
{
	string Birthday { get; set; }
}