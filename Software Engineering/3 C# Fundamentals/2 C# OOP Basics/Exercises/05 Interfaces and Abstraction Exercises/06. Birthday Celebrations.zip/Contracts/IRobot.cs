﻿public interface IRobot : IIdable
{
	string Model { get; set; }
}