﻿public interface ICitizen : ICitizenOrPet
{
	string Name { get; set; }

	int Age { get; set; }
}
