﻿public interface IIdable
{
	string Id { get; set; }
}