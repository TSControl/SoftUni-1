﻿using System;
using System.Collections.Generic;
using System.Linq;

class StartUp
{
	static void Main()
	{
		var citizensAndPets = new List<ICitizenOrPet>();
		string line;

		while ((line = Console.ReadLine()) != "End")
		{
			var tokens = line.Split();

			if (tokens.Length == 5)
			{
				var name = tokens[1];
				var age = int.Parse(tokens[2]);
				var id = tokens[3];
				var birthday = tokens[4];

				var citizen = new Citizen(name, age, id, birthday);
				citizensAndPets.Add(citizen);

			}
			else if (tokens[0] == "Pet")
			{
				var petName = tokens[1];
				var petBirthday = tokens[2];

				var pet = new Pet(petName, petBirthday);

				citizensAndPets.Add(pet);
			}
		}

		var year = Console.ReadLine();
		citizensAndPets.Where(c => c.Birthday.Substring(c.Birthday.Length - 4) == year).ToList().ForEach(c => Console.WriteLine(c.ToString()));
	}
}