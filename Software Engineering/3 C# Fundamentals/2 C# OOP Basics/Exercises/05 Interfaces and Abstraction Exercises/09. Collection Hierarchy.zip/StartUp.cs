﻿using System;
using System.Collections.Generic;
using System.Linq;

class StartUp
{
	static void Main()
	{
		var addCollection = new AddCollection<string>();
		var addRemoveCollection = new AddRemoveCollection<string>();
		var myList = new MyList<string>();

		var lineSplit = Console.ReadLine().Trim().Split().ToArray();

		var outputLine1 = new List<int>();
		var outputLine2 = new List<int>();
		var outputLine3 = new List<int>();

		for (int i = 0; i < lineSplit.Count(); i++)
		{
			outputLine1.Add(addCollection.Add(lineSplit[i]));
			outputLine2.Add(addRemoveCollection.Add(lineSplit[i]));
			outputLine3.Add(myList.Add(lineSplit[i]));
		}

		var outputLine4 = new List<string>();
		var outputLine5 = new List<string>();

		var amountRemoveOperations = int.Parse(Console.ReadLine());

		for (int i = 0; i < amountRemoveOperations; i++)
		{
			outputLine4.Add(addRemoveCollection.Remove());
			outputLine5.Add(myList.Remove());
		}

		Console.WriteLine(string.Join(' ', outputLine1));
		Console.WriteLine(string.Join(' ', outputLine2));
		Console.WriteLine(string.Join(' ', outputLine3));
		Console.WriteLine(string.Join(' ', outputLine4));
		Console.WriteLine(string.Join(' ', outputLine5));
	}
}