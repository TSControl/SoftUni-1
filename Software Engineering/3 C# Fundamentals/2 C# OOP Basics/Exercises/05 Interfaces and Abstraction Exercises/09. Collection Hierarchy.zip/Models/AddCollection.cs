﻿using System.Collections.Generic;

public class AddCollection<T> : IAddCollection<T>
{
	internal List<T> collection;

	public AddCollection()
	{
		this.collection = new List<T>();
	}

	public virtual int Add(T item)
	{
		var index = this.collection.Count;

		this.collection.Add(item);

		return index;
	}
}