﻿using System.Collections.Generic;
using System.Linq;

public class AddRemoveCollection<T> : AddCollection<T>, IAddRemoveCollection<T>
{
	public AddRemoveCollection()
		:base()
	{
	}

	public override int Add(T item)
	{
		this.collection.Insert(0, item);

		return 0;
	}

	public virtual T Remove()
	{
		var itemToRemove = base.collection.LastOrDefault();

		base.collection.RemoveAt(base.collection.Count - 1);

		return itemToRemove;
	}
}