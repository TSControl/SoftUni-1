﻿using System.Collections.Generic;
using System.Linq;

public class MyList<T> : AddRemoveCollection<T>, IMyList<T>
{
	public MyList()
		:base()
	{
		base.collection = new List<T>();
	}

	public int Used
	{
		get
		{
			return base.collection.Count;
		}
	}

	public override T Remove()
	{
		var itemToRemove = base.collection.FirstOrDefault();

		base.collection.RemoveAt(0);

		return itemToRemove;
	}
}