﻿using System;
using System.Collections.Generic;

class StartUp
{
	static void Main()
	{
		var citizens = new List<Citizen>();

		string line;
		while ((line = Console.ReadLine()) != "End")
		{
			var lineSplit = line.Trim().Split();

			var name = lineSplit[0];
			var country = lineSplit[1];
			var age = int.Parse(lineSplit[2]);

			var citizen = new Citizen(name, age, country);

			citizens.Add(citizen);
		}

		foreach (var citizen in citizens)
		{
			Console.WriteLine(((IPerson)citizen).GetName());
			Console.WriteLine(((IResident)citizen).GetName());
		}
	}
}