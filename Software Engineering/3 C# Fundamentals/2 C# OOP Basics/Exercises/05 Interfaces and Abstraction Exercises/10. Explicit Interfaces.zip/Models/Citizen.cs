﻿public class Citizen : IPerson, IResident
{
	public string Name { get; set; }

	public int Age { get; set; }

	public string Country { get; set; }

	public Citizen(string name, int age, string country)
	{
		this.Name = name;
		this.Age = age;
		this.Country = country;
	}

	string IResident.GetName()
	{
		var output = "Mr/Ms/Mrs " + this.Name;

		return output;
	}

	string IPerson.GetName()
	{
		var output = this.Name;

		return output;
	}
}