﻿public interface IPerson
{
	int Age { get; set; }
	string Country { get; set; }

	string GetName();
}