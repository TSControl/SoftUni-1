﻿public interface ICitizen : IIdable
{
	string Name { get; set; }

	int Age { get; set; }
}
