﻿using System;
using System.Collections.Generic;
using System.Linq;

class StartUp
{
	static void Main()
	{
		var inhabitants = new List<IIdable>();
		string line;

		while ((line = Console.ReadLine()) != "End")
		{
			var tokens = line.Split();

			if (tokens.Length == 2)
			{
				var model = tokens[0];
				var id = tokens[1];

				var robot = new Robot(model, id);
				inhabitants.Add(robot);
			}
			else
			{
				var name = tokens[0];
				var age = int.Parse(tokens[1]);
				var id = tokens[2];

				var citizen = new Citizen(name, age, id);
				inhabitants.Add(citizen);
			}
		}

		var invalidIdChars = Console.ReadLine();
		inhabitants.Where(i => i.Id.Substring(i.Id.Length - invalidIdChars.Length).Equals(invalidIdChars)).ToList().ForEach(i => Console.WriteLine(i.ToString()));
	}
}