﻿public interface IFerrari
{
	string Driver { get; set; }

	string UseBrakes();

	string GazPedal();
}