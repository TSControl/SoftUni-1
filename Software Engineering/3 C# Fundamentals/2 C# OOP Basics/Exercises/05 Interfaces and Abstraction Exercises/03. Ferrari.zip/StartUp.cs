﻿using System;

class StartUp
{
	static void Main()
	{
		var driver = Console.ReadLine();

		var ferrari = new Ferrari(driver);

		Console.WriteLine(ferrari.ToString());
	}
}