﻿using System.Text;

public class Ferrari : IFerrari
{
	private string model = "488-Spider";

	public Ferrari(string driver)
	{
		this.Driver = driver;
	}

	public string Driver { get; set; }

	public string UseBrakes()
	{
		return "Brakes!";
	}

	public string GazPedal()
	{
		return "Zadu6avam sA!";
	}

	public override string ToString()
	{
		var builder = new StringBuilder();
		builder.Append(model + "/");
		builder.Append(this.UseBrakes() + "/");
		builder.Append(this.GazPedal() + "/");
		builder.AppendLine(this.Driver);
		return builder.ToString();
	}
}