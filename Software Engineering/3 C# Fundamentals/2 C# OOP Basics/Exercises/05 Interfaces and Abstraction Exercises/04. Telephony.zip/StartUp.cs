﻿using System;

class StartUp
{
	static void Main()
	{
		var phoneNumbers = Console.ReadLine().Split(' ');
		var sites = Console.ReadLine().Split(' ');

		var smartphone = new Smartphone("Smartphone");

		foreach (var phone in phoneNumbers)
		{
			Console.WriteLine(smartphone.Call(phone));
		}

		foreach (var site in sites)
		{
			Console.WriteLine(smartphone.Browse(site));
		}
	}
}