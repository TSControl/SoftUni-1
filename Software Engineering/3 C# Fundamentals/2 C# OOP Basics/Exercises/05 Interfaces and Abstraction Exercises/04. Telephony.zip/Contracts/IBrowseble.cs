﻿public interface IBrowseble
{
	string Browse(string site);
}