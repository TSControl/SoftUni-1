﻿using System.Linq;

public class Smartphone : IBrowseble, ICallable
{
	public string Model { get; private set; }

	public Smartphone(string model)
	{
		this.Model = model;
	}

	public string Call(string number)
	{
		if (!number.All(char.IsDigit))
		{
			return "Invalid number!";
		}
		else
		{
			return $"Calling... {number}";
		}
	}

	public string Browse(string site)
	{
		if (site.Any(char.IsDigit))
		{
			return "Invalid URL!";
		}
		else
		{
			return $"Browsing: {site}!";
		}
	}
}