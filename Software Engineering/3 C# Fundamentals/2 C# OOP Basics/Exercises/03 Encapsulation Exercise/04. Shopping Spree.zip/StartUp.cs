﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Problem1
{
    class StartUp
    {
        static void Main(string[] args)
        {
            var people = new List<Person>();
            var products = new List<Product>();

            var peopleSplit = Console.ReadLine().Trim().Split("=;".ToCharArray()).ToArray();
            for (int i = 0; i < peopleSplit.Length; i++)
            {
                try
                {
                    var name = peopleSplit[i++];
                    var money = decimal.Parse(peopleSplit[i]);
                    var person = new Person(name, money);
                    people.Add(person);
                }
                catch (ArgumentException e)
                {
                    Console.WriteLine(e.Message);
                    return;
                }

            }

            var productsSplit = Console.ReadLine().Split("=; ".ToCharArray(), StringSplitOptions.RemoveEmptyEntries).ToArray();
            for (int i = 0; i < productsSplit.Length; i++)
            {
                try
                {
                    var name = productsSplit[i++];
                    var price = decimal.Parse(productsSplit[i]);
                    var product = new Product(name, price);
                    products.Add(product);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    return;
                }
            }

            string line;
            while ((line = Console.ReadLine().Trim()) != "END")
            {
                try
                {
                    var lineSplit = line.Split();
                    var personName = lineSplit[0];
                    var productName = lineSplit[1];
                    var person = people.FirstOrDefault(p => p.Name == personName);
                    var product = products.FirstOrDefault(p => p.Name == productName);

                    if (person != null)
                        person.TryBuyProduct(product);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            }

            if (people.Any())
            {
                foreach (var person in people)
                {
                    Console.Write($"{person.Name} - ");
                    if (person.BagOfProducts.Count == 0)
                    {
                        Console.WriteLine("Nothing bought");
                    }
                    else
                    {
                        Console.WriteLine(string.Join(", ", person.BagOfProducts));
                    }
                }
            }
        }
    }
}
