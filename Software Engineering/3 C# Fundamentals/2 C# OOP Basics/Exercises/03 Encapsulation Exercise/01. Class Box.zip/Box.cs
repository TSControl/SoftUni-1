﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Problem1
{
    public class Box
    {
        private double length;
        private double width;
        private double height;

        public Box(double length, double width, double height)
        {
            this.Length = length;
            this.Width = width;
            this.Height = height;
        }

        public double Length
        {
            get { return length; }
            set { length = value; }
        }

        public double Width
        {
            get { return width; }
            set { width = value; }
        }

        public double Height
        {
            get { return height; }
            set { height = value; }
        }

        public double SurfaceArea()
        {
            return 2 * (this.Length * this.Height + this.Length * this.Width + this.Height * this.Width);
        }

        public double LateralSurfaceArea()
        {
            return 2 * (this.Length * this.Height + this.Height * this.Width);
        }

        public double Volume()
        {
            return this.Length * this.Height * this.Width;
        }
    }
}
