﻿using Problem0.Models;
using System;

namespace Problem0
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                var pizzaTokens = Console.ReadLine().Trim().Split();
                string pizzaName;
                if (pizzaTokens.Length == 1)
                {
                    pizzaName = null;
                }
                else
                {
                    pizzaName = pizzaTokens[1];
                }
                var pizza = new Pizza(pizzaName);

                var doughTokens = Console.ReadLine().Trim().Split();
                var flourType = doughTokens[1];
                var bakingTechnique = doughTokens[2];
                var doughWeight = int.Parse(doughTokens[3]);
                var dough = new Dough(flourType, bakingTechnique, doughWeight);
                pizza.Dough = dough;

                string line;
                while ((line = Console.ReadLine().Trim()) != "END")
                {
                    var toppingTokens = line.Split();
                    var toppingType = toppingTokens[1];
                    var toppingWeight = int.Parse(toppingTokens[2]);
                    var topping = new Topping(toppingWeight, toppingType);
                    pizza.AddTopping(topping);
                }

                Console.WriteLine($"{pizza.Name} - {pizza.CalculateCalories():F2} Calories.");
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}
