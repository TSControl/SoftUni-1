﻿namespace Problem0.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class Pizza
    {
        private const int MAX_TOPPING_COUNT = 10;
        private const int NAME_MIN_LENGTH = 1;
        private const int NAME_MAX_LENGTH = 15;

        private string name;
        private Dough dough;
        private List<Topping> toppings;

        public Pizza(string name)
        {
            this.Name = name;
            this.Toppings = new List<Topping>();
        }

        public string Name
        {
            get { return name; }
            private set
            {
                if (value == null || value.Length < NAME_MIN_LENGTH || value.Length > NAME_MAX_LENGTH)
                {
                    throw new ArgumentException($"Pizza name should be between {NAME_MIN_LENGTH} and {NAME_MAX_LENGTH} symbols.");
                }
                name = value;
            }
        }

        public Dough Dough
        {
            private get { return dough; }
            set { dough = value; }
        }

        private List<Topping> Toppings
        {
            get { return toppings; }
            set { toppings = value; }
        }

        public double CalculateCalories()
        {
            return this.Dough.CalculateCalories() + this.Toppings.Sum(t => t.CalculateCalories());
        }

        public int ToppingsCount()
        {
            return this.Toppings.Count;
        }

        public void AddTopping(Topping topping)
        {
            if (this.Toppings.Count == MAX_TOPPING_COUNT)
            {
                throw new ArgumentException($"Number of toppings should be in range [0..{MAX_TOPPING_COUNT}].");
            }
            this.Toppings.Add(topping);
        }
    }
}
