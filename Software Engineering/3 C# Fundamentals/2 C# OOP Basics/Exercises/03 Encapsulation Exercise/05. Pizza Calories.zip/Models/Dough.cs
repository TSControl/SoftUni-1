﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Problem0
{
    public class Dough
    {
        private const int BASE_MODIFIER = 2;
        private const int minWeight = 1;
        private const int maxWeight = 200;

        private Dictionary<string, double> flourTypes = new Dictionary<string, double>()
        {
            ["white"] = 1.5,
            ["wholegrain"] = 1.0
        };
        private Dictionary<string, double> bakingTechniques = new Dictionary<string, double>()
        {
            ["crispy"] = 0.9,
            ["chewy"] = 1.1,
            ["homemade"] = 1.0
        };

        private int weight;
        private string flourType;
        private string bakingTechnique;

        public Dough(string flourType, string bakingTechnique, int weight)
        {
            this.FlourType = flourType;
            this.BakingTechnique = bakingTechnique;
            this.Weight = weight;
        }

        private int Weight
        {
            get { return weight; }
            set
            {
                if (value < minWeight || value > maxWeight)
                {
                    throw new ArgumentException($"Dough weight should be in the range [{minWeight}..{maxWeight}].");
                }
                weight = value;
            }
        }

        private string FlourType
        {
            get { return flourType; }
            set
            {
                if (!flourTypes.Keys.Contains(value.ToLower()))
                {
                    throw new ArgumentException("Invalid type of dough.");
                }
                flourType = value.ToLower();
            }
        }

        private string BakingTechnique
        {
            get { return bakingTechnique; }
            set
            {
                if (!bakingTechniques.Keys.Contains(value.ToLower()))
                {
                    throw new ArgumentException("Invalid type of dough.");
                }
                bakingTechnique = value.ToLower();
            }
        }

        public double CalculateCalories()
        {
            return BASE_MODIFIER * this.Weight * flourTypes[this.FlourType] * bakingTechniques[this.BakingTechnique];
        }
    }
}
