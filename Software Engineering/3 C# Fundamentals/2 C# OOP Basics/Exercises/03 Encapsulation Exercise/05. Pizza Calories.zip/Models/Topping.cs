﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Problem0.Models
{
    public class Topping
    {
        private const int BASE_MODIFIER = 2;
        private const int minWeight = 1;
        private const int maxWeight = 50;

        private Dictionary<string, double> toppingTypes = new Dictionary<string, double>()
        {
            ["meat"] = 1.2,
            ["veggies"] = 0.8,
            ["cheese"] = 1.1,
            ["sauce"] = 0.9
        };

        private int weight;
        private string type;
        private string tempType;

        public Topping(int weight, string type)
        {
            tempType = type;
            this.Weight = weight;
            this.Type = type;
        }

        private int Weight
        {
            get { return weight; }
            set
            {
                if (value < minWeight || value > maxWeight)
                {
                    throw new ArgumentException($"{tempType} weight should be in the range [{minWeight}..{maxWeight}].");
                }
                weight = value;
            }
        }

        private string Type
        {
            get { return type; }
            set
            {
                if (!toppingTypes.Keys.Contains(value.ToLower()))
                {
                    throw new ArgumentException($"Cannot place {value} on top of your pizza.");
                }
                type = value.ToLower();
            }
        }



        public double CalculateCalories()
        {
            return BASE_MODIFIER * this.Weight * toppingTypes[this.Type];
        }
    }
}
