﻿public class Mood
{
	public int Points { get; set; }

	public Mood(int points)
	{
		this.Points = points;
	}

	public string GetMood()
	{
		string result = null;

		if (this.Points < -5)
		{
			result = "Angry";
		}
		else if (this.Points >= -5 && this.Points <= 0)
		{
			result = "Sad";
		}
		else if (this.Points >= 1 && this.Points <= 15)
		{
			return "Happy";
		}
		else
		{
			return "JavaScript";
		}

		return result;
	}
}
