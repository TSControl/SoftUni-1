﻿public class FoodFactory
{
	public Food MakeFood(string type)
	{
		return new Food(type);
	}
}
