﻿using System;
using System.Collections.Generic;
using System.Linq;

class StartUp
{
	static void Main()
	{
		var foodTokens = Console.ReadLine().Trim().Split().Select(s => s.ToLower()).ToArray();

		var foods = new List<Food>();
		var moods = new List<Mood>();

		var foodFactory = new FoodFactory();
		var moodFactory = new MoodFactory();

		int moodPoints = 0;


		foreach (var type in foodTokens)
		{
			foods.Add(foodFactory.MakeFood(type));
		}

		foreach (var food in foods)
		{
			moodPoints += food.getPoints();
		}

		var mood = moodFactory.MakeMood(moodPoints);

		string moodString = mood.GetMood();

		Console.WriteLine(moodPoints);
		Console.WriteLine(moodString);
	}
}

