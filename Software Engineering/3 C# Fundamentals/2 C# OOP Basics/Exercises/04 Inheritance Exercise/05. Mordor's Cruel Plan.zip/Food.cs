﻿using System.Collections.Generic;

public class Food
{
	private Dictionary<string, int> pointsPerType = new Dictionary<string, int>()
	{
		["cram"] = 2,
		["lembas"] = 3,
		["apple"] = 1,
		["melon"] = 1,
		["honeycake"] = 5,
		["mushrooms"] = -10
	};

	public string Type { get; set; }

	public Food(string type)
	{
		this.Type = type;
	}

	public int getPoints()
	{
		int result = 0;
		if (!this.pointsPerType.ContainsKey(this.Type))
		{
			result = -1;
		}
		else
		{
			result = this.pointsPerType[this.Type];
		}
		return result;
	}
}
