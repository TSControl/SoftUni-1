﻿public class MoodFactory
{
	public Mood MakeMood(int points)
	{
		return new Mood(points);
	}
}