﻿namespace Problem2
{
    using Problem2.Models;
    using System;
    using System.Collections.Generic;

    class StartUp
    {
        static void Main(string[] args)
        {
            var animals = new List<Animal>();

            string line;
            while ((line = Console.ReadLine().Trim()) != "Beast!")
            {
                try
                {
                    var animalType = line;
                    var animalTokens = Console.ReadLine().Trim().Split();
                    var animalName = animalTokens[0];
                    int animalAge;
                    if (!int.TryParse(animalTokens[1], out animalAge))
                    {
                        throw new ArgumentException("Invalid input!");
                    }
                    var animalSex = animalTokens[2];

                    switch (animalType)
                    {
                        case "Dog":
                            var dog = new Dog(animalName, animalAge, animalSex);
                            animals.Add(dog);
                            break;
                        case "Cat":
                            var cat = new Cat(animalName, animalAge, animalSex);
                            animals.Add(cat);
                            break;
                        case "Frog":
                            var frog = new Frog(animalName, animalAge, animalSex);
                            animals.Add(frog);
                            break;
                        case "Kitten":
                            var kitten = new Kitten(animalName, animalAge);
                            animals.Add(kitten);
                            break;
                        case "Tomcat":
                            var tomcat = new Tomcat(animalName, animalAge);
                            animals.Add(tomcat);
                            break;
                        default:
                            throw new ArgumentException("Invalid input!");
                    }
                }
                catch (ArgumentException ae)
                {
                    Console.WriteLine(ae.Message);
                }

            }

            foreach (var animal in animals)
            {
                var animalType = animal.GetType().Name;
                Console.WriteLine(animalType);
                Console.WriteLine($"{animal.Name} {animal.Age} {animal.Sex}");
                Console.WriteLine(animal.ProduceSound());
            }
        }
    }
}