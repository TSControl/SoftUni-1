﻿using System;
using System.Text;

namespace Problem0.Models
{
    public class Worker : Human
    {
        private decimal weekSalary;
        private decimal workHoursPerDay;

        public Worker(string firstName, string lastName, decimal weekSalary, decimal workHoursPerDay)
            :base(firstName, lastName)
        {
            this.WeekSalary = weekSalary;
            this.WorkHoursPerDay = workHoursPerDay;
        }

        public decimal WeekSalary
        {
            get { return weekSalary; }
            set
            {
                if (value <= 10M)
                {
                    throw new ArgumentException("Expected value mismatch! Argument: weekSalary");
                }
                weekSalary = value;
            }
        }

        public decimal WorkHoursPerDay
        {
            get { return workHoursPerDay; }
            set
            {
                if (value < 1 || value > 12)
                {
                    throw new ArgumentException("Expected value mismatch! Argument: workHoursPerDay");
                }
                workHoursPerDay = value;
            }
        }

        public decimal MoneyPerHour()
        {
            return this.WeekSalary / (WorkHoursPerDay * 5);
        }

        public override string ToString()
        {
            var builder = new StringBuilder();
            builder.Append($"First Name: {this.FirstName}");
            builder.Append(Environment.NewLine);
            builder.Append($"Last Name: {this.LastName}");
            builder.Append(Environment.NewLine);
            builder.Append($"Week Salary: {this.WeekSalary:F2}");
            builder.Append(Environment.NewLine);
            builder.Append($"Hours per day: {this.WorkHoursPerDay:F2}");
            builder.Append(Environment.NewLine);
            builder.Append($"Salary per hour: {this.MoneyPerHour():F2}");

            return builder.ToString();
        }
    }
}
