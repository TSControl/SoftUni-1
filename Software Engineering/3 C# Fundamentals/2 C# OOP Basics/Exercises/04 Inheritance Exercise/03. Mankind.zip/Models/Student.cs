﻿using System;
using System.Text;
using System.Text.RegularExpressions;

namespace Problem0.Models
{
    public class Student : Human
    {
        private string facultyNumber;

        public Student(string firstName, string lastName, string facultyNumber)
            : base(firstName, lastName)
        {
            this.FacultyNumber = facultyNumber;
        }

        public string FacultyNumber
        {
            get { return facultyNumber; }
            set
            {
                if ((value.Length < 5 || value.Length > 10) || !Regex.IsMatch(value, @"^[\w\d]+$"))
                {
                    throw new ArgumentException("Invalid faculty number!");
                }
                facultyNumber = value;
            }
        }


        public override string ToString()
        {
            var builder = new StringBuilder();
            builder.Append($"First Name: {this.FirstName}");
            builder.Append(Environment.NewLine);
            builder.Append($"Last Name: {this.LastName}");
            builder.Append(Environment.NewLine);
            builder.Append($"Faculty number: {this.FacultyNumber}");

            return builder.ToString();
        }
    }
}
