﻿using Problem0.Models;
using System;

namespace Problem0
{
    class StartUp
    {
        static void Main(string[] args)
        {
            try
            {
                var studentTokens = Console.ReadLine().Trim().Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries);
                var studentFirstName = studentTokens[0];
                var studentLastName = studentTokens[1];
                var studentFacultyNumber = studentTokens[2];
                var student = new Student(studentFirstName, studentLastName, studentFacultyNumber);

                var workerTokens = Console.ReadLine().Trim().Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries);
                var workerFirstName = workerTokens[0];
                var workerLastName = workerTokens[1];
                var workerWeekSalary = decimal.Parse(workerTokens[2]);
                var workerWeekWorkingHours = decimal.Parse(workerTokens[3]);
                var worker = new Worker(workerFirstName, workerLastName, workerWeekSalary, workerWeekWorkingHours);

                Console.WriteLine(student);
                Console.WriteLine();
                Console.WriteLine(worker);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}