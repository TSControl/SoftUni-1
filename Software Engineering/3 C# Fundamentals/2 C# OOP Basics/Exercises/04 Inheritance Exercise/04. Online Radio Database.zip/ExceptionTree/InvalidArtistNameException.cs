﻿namespace OnlineRadioDatabase.ExceptionTree
{
    public class InvalidArtistNameException : InvalidSongException
    {
        public InvalidArtistNameException()
            :base()
        {

        }

        public InvalidArtistNameException(string message)
            :base(message)
        {

        }

        public InvalidArtistNameException(int artistNameMinLength, int artistNameMaxLength)
            :base($"Artist name should be between {artistNameMinLength} and {artistNameMaxLength} symbols.")
        {

        }
    }
}
