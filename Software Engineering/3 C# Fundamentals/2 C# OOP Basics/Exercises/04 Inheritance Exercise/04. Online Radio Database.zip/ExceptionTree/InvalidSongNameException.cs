﻿namespace OnlineRadioDatabase.ExceptionTree
{
    public class InvalidSongNameException :InvalidSongException
    {
        public InvalidSongNameException()
            :base()
        {

        }

        public InvalidSongNameException(string message)
            :base(message)
        {

        }

        public InvalidSongNameException(int songNameMinLength, int songNameMaxLength)
            :base($"Song name should be between {songNameMinLength} and {songNameMaxLength} symbols.")
        {

        }
    }
}
