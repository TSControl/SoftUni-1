﻿namespace Problem0
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text.RegularExpressions;
    using OnlineRadioDatabase.ExceptionTree;
    using Problem0.Models;

    class StartUp
    {
        static void Main(string[] args)
        {
            var songs = new List<Song>();

            var songCount = int.Parse(Console.ReadLine());
            for (int i = 0; i < songCount; i++)
            {
                try
                {
                    var input = Console.ReadLine();
                    var songTokens = input.Split(';', StringSplitOptions.RemoveEmptyEntries);

                    var indexOfSeparation = songTokens[2].IndexOf(':');
                    if (songTokens.Length < 3 || indexOfSeparation < 1 || indexOfSeparation > songTokens[2].Length - 2)
                    {
                        throw new InvalidSongException();
                    }

                    var artistName = songTokens[0];
                    var songName = songTokens[1];
                    var timeTokens = songTokens[2].Split(':', StringSplitOptions.RemoveEmptyEntries);
                    var minutes = int.Parse(timeTokens[0]);
                    var seconds = int.Parse(timeTokens[1]);

                    var song = new Song(artistName, songName, minutes, seconds);
                    songs.Add(song);
                    Console.WriteLine("Song added.");
                }
                catch (InvalidSongException ise)
                {
                    Console.WriteLine(ise.Message);
                }
                catch (FormatException fe) //?
                {
                    Console.WriteLine("Invalid song length.");
                }
            }
            
            var playlistLengthSeconds = songs.Sum(s => s.Minutes * 60 + s.Seconds);
            var hours = playlistLengthSeconds / 3600;
            playlistLengthSeconds -= hours * 3600;
            var minutesToPrint = playlistLengthSeconds / 60;
            playlistLengthSeconds -= minutesToPrint * 60;
            Console.WriteLine($"Songs added: {songs.Count}");
            Console.WriteLine($"Playlist length: {hours}h {minutesToPrint}m {playlistLengthSeconds}s");
        }
    }
}