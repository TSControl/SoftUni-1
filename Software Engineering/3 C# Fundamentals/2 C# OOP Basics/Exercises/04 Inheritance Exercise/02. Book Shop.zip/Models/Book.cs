﻿using System;
using System.Text;
using System.Text.RegularExpressions;

namespace Problem0.Models
{
    public class Book
    {
        private string title;
        private string author;
        private decimal price;

        public Book(string author, string title, decimal price)
        {
            this.Title = title;
            this.Author = author;
            this.Price = price;
        }

        public string Title
        {
            get { return title; }
            set
            {
                if (value.Length < 3)
                {
                    throw new ArgumentException("Title not valid!");
                }
                title = value;
            }
        }

        public string Author
        {
            get { return author; }
            set
            {
                var regex = new Regex(@"\w+\s\d\w+");
                if (regex.Match(value).Success)
                {
                    throw new ArgumentException("Author not valid!");
                }
                author = value;
            }
        }

        public virtual decimal Price
        {
            get { return price; }
            set
            {
                if (value <= 0)
                {
                    throw new ArgumentException("Price not valid!");
                }
                price = value;
            }
        }

        public override string ToString()
        {
            var builder = new StringBuilder();
            builder.Append($"Type: {this.GetType().Name}");
            builder.Append(Environment.NewLine);
            builder.Append($"Title: {this.Title}");
            builder.Append(Environment.NewLine);
            builder.Append($"Author: {this.Author}");
            builder.Append(Environment.NewLine);
            builder.Append($"Price: {this.Price:F2}");

            return builder.ToString();
        }
    }
}
