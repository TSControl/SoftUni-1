﻿using System;

public class BankAccount
{
    private int id;
    private decimal balance;

    public int ID
    {
        get { return this.id; }
        set { this.id = value; }
    }
    public decimal Balance
    {
        get { return this.balance; }
        set { this.balance = value; }
    }

    public BankAccount()
    {
    }

    public void Deposit(decimal amount)
    {
        if (amount <= 0)
        {
            throw new Exception("Please deposit positive amount of money, dickhead.");
        }
        else
        {
            this.Balance += amount;
        }
    }

    public void Withdraw(decimal amount)
    {
        if (amount > this.Balance)
        {
            throw new Exception("Insufficient balance");
        }
        else
        {
            this.Balance -= amount;
        }
    }

    public override string ToString()
    {
        return $"Account ID{this.ID}, balance {this.Balance:F2}";
    }
}
