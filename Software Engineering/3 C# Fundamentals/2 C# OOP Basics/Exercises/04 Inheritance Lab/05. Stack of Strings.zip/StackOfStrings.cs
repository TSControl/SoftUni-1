﻿using System.Collections.Generic;

public class StackOfStrings
{
    List<string> data = new List<string>();

    public void Push(string str)
    {
        data.Add(str);
    }

    public string Pop()
    {
        string output = string.Empty;
        if (!IsEmpty())
        {
            var index = data.Count - 1;
            output = data[index];
            data.RemoveAt(index);
        }

        return output;
    }

    public string Peek()
    {
        string output = string.Empty;
        if (!IsEmpty())
        {
            output = data[data.Count - 1];
        }
        return output;

    }

    public bool IsEmpty()
    {
        if (data.Count == 0)
            return true;
        return false;
    }
}
