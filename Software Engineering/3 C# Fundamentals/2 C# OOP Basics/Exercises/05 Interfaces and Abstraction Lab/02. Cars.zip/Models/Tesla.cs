﻿using System.Text;

public class Tesla : ICar, IElectricCar
{
	public Tesla(string model, string color, int battery)
	{
		this.Model = model;
		this.Color = color;
		this.Battery = battery;
	}

	public string Model { get; set; }

	public string Color { get; set; }

	public int Battery { get; set; }

	public string Start()
	{
		return "";
	}

	public string Stop()
	{
		return "";
	}

	public override string ToString()
	{
		var builder = new StringBuilder();

		builder.AppendLine($"{this.Color} Tesla {this.Model} with {this.Battery} Batteries");
		builder.AppendLine("Engine start");
		builder.AppendLine("Breaaak!");

		return builder.ToString();
	}
}