﻿using System.Text;

public class Seat : ICar
{
	public string Model { get; set; }

	public string Color { get; set; }

	public Seat(string model, string color)
	{
		this.Model = model;
		this.Color = color;
	}

	public string Start()
	{
		return "";
	}

	public string Stop()
	{
		return "";
	}

	public override string ToString()
	{
		var builder = new StringBuilder();

		builder.AppendLine($"{this.Color} Seat {this.Model}");
		builder.AppendLine("Engine start");
		builder.AppendLine("Breaaak!");

		return builder.ToString();
	}
}