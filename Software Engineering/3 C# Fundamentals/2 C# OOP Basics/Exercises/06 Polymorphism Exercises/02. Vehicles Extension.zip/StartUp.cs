﻿using System;

class StartUp
{
	static void Main()
	{
		const double BUS_FUEL_INCREASE = 1.4;
		const double CAR_FUEL_INCREASE = 0.9;
		const double TRUCK_FUEL_INCREASE = 1.6;

		var carTokens = Console.ReadLine().Split();

		var carFuelQuantity = double.Parse(carTokens[1]);
		var carFuelConsumption = double.Parse(carTokens[2]);
		var carTankCapacity = double.Parse(carTokens[3]);

		var car = new Car(carFuelQuantity, carFuelConsumption, carTankCapacity);

		var truckTokens = Console.ReadLine().Split();

		var truckFuelQuantity = double.Parse(truckTokens[1]);
		var truckFuelConsumption = double.Parse(truckTokens[2]);
		var truckTankCapacity = double.Parse(truckTokens[3]);

		var truck = new Truck(truckFuelQuantity, truckFuelConsumption, truckTankCapacity);

		var busTokens = Console.ReadLine().Split();

		var busFuelQuantity = double.Parse(busTokens[1]);
		var busFuelConsumption = double.Parse(busTokens[2]);
		var busTankCapacity = double.Parse(busTokens[3]);

		var bus = new Bus(busFuelQuantity, busFuelConsumption, busTankCapacity);

		var n = int.Parse(Console.ReadLine());
		for (int i = 0; i < n; i++)
		{
			try
			{
				var commandTokens = Console.ReadLine().Split();
				if (commandTokens[0] == "Drive")
				{
					if (commandTokens[1] == "Car")
					{
						car.Drive(double.Parse(commandTokens[2]), CAR_FUEL_INCREASE);
					}
					else if (commandTokens[1] == "Truck")
					{
						truck.Drive(double.Parse(commandTokens[2]), TRUCK_FUEL_INCREASE);
					}
					else
					{
						bus.Drive(double.Parse(commandTokens[2]), BUS_FUEL_INCREASE);
					}
				}
				else if (commandTokens[0] == "Refuel")
				{
					if (commandTokens[1] == "Car")
					{
						car.Refuel(double.Parse(commandTokens[2]));
					}
					else if (commandTokens[1] == "Truck")
					{
						truck.Refuel(double.Parse(commandTokens[2]));
					}
					else
					{
						bus.Refuel(double.Parse(commandTokens[2]));
					}
				}
				else //DriveEmpty
				{
					bus.Drive(double.Parse(commandTokens[2]), 0);
				}
			}
			catch (ArgumentException e)
			{
				Console.WriteLine(e.Message);
			}
		}

		Console.WriteLine(car.ToString());
		Console.WriteLine(truck.ToString());
		Console.WriteLine(bus.ToString());
	}
}