﻿using System;

public class Vehicle : IVehicle
{

	public double FuelConsumption { get; set; }

	public double TankCapacity { get; set; }

	private double fuelQuantity;

	public Vehicle(double fuelQuantity, double fuelConsumption, double tankCapacity)
	{
		this.FuelConsumption = fuelConsumption;
		this.TankCapacity = tankCapacity;
		this.FuelQuantity = fuelQuantity;
	}

	public double FuelQuantity
	{
		get { return fuelQuantity; }
		set
		{
			if (value > this.TankCapacity)
			{
				fuelQuantity = 0;
			}
			else
			{
				fuelQuantity = value;
			}
		}
	}

	public void Drive(double distance, double fuelIncrease)
	{
		var totalFuelConsumption = this.FuelConsumption + fuelIncrease;
		if (totalFuelConsumption * distance <= this.FuelQuantity)
		{
			this.FuelQuantity -= totalFuelConsumption * distance;
			Console.WriteLine($"{this.GetType().Name} travelled {distance} km");
		}
		else
		{
			throw new ArgumentException($"{this.GetType().Name} needs refueling");
		}
	}

	public virtual void Refuel(double fuelAmount)
	{
		if (fuelAmount <= 0)
		{
			throw new ArgumentException("Fuel must be a positive number");
		}

		if (fuelAmount + this.FuelQuantity > this.TankCapacity)
		{
			throw new ArgumentException($"Cannot fit {fuelAmount} fuel in the tank");
		}
		else
		{
			this.FuelQuantity += fuelAmount;
		}
	}

	public override string ToString()
	{
		return $"{this.GetType().Name}: {this.FuelQuantity:F2}";
	}
}