﻿public interface IVehicle
{
	double FuelQuantity { get; set; }

	double FuelConsumption { get; set; }

	double TankCapacity { get; set; }

	void Drive(double distance, double fuelIncrease);

	void Refuel(double fuelAmount);
}