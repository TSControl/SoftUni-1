﻿using System;

public class Truck : IVehicle
{
	private const double CONDITIONER_ADDITION = 1.6;
	private const double HOLE_MULTIPLIER = 0.95;

	public double FuelQuantity { get; set; }

	public double FuelConsumption { get; set; }

	public Truck(double fuelQuantity, double fuelConsumption)
	{
		this.FuelQuantity = fuelQuantity;
		this.FuelConsumption = fuelConsumption + CONDITIONER_ADDITION;
	}

	public void Drive(double distance)
	{
		if (this.FuelConsumption * distance <= this.FuelQuantity)
		{
			this.FuelQuantity -= this.FuelConsumption * distance;
			Console.WriteLine($"Truck travelled {distance} km");
		}
		else
		{
			Console.WriteLine("Truck needs refueling");
		}
	}

	public void Refuel(double fuelAmount)
	{
		this.FuelQuantity += fuelAmount * HOLE_MULTIPLIER;
	}

	public override string ToString()
	{
		return $"Truck: {this.FuelQuantity:F2}";
	}
}