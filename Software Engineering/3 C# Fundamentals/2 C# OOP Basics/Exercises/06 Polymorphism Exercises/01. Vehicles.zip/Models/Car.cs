﻿using System;

public class Car : IVehicle
{
	private const double CONDITIONER_ADDITION = 0.9;

	public double FuelQuantity { get; set; }

	public double FuelConsumption { get; set; }

	public Car(double fuelQuantity, double fuelConsumption)
	{
		this.FuelQuantity = fuelQuantity;
		this.FuelConsumption = fuelConsumption + CONDITIONER_ADDITION;
	}

	public void Drive(double distance)
	{
		if (this.FuelConsumption * distance <= this.FuelQuantity)
		{
			this.FuelQuantity -= this.FuelConsumption * distance;
			Console.WriteLine($"Car travelled {distance} km");
		}
		else
		{
			Console.WriteLine("Car needs refueling");
		}
	}

	public void Refuel(double fuelAmount)
	{
		this.FuelQuantity += fuelAmount;

	}

	public override string ToString()
	{
		return $"Car: {this.FuelQuantity:F2}";
	}
}