﻿using System;

class StartUp
{
	static void Main()
	{
		var carTokens = Console.ReadLine().Split();

		var carFuelQuantity = double.Parse(carTokens[1]);
		var carFuelConsumption = double.Parse(carTokens[2]);

		var car = new Car(carFuelQuantity, carFuelConsumption);

		var truckTokens = Console.ReadLine().Split();

		var truckFuelQuantity = double.Parse(truckTokens[1]);
		var truckFuelConsumption = double.Parse(truckTokens[2]);

		var truck = new Truck(truckFuelQuantity, truckFuelConsumption);

		var n = int.Parse(Console.ReadLine());
		for (int i = 0; i < n; i++)
		{
			var commandTokens = Console.ReadLine().Split();
			if (commandTokens[0] == "Drive")
			{
				if (commandTokens[1] == "Car")
				{
					car.Drive(double.Parse(commandTokens[2]));
				}
				else
				{
					truck.Drive(double.Parse(commandTokens[2]));
				}
			}
			else
			{
				if (commandTokens[1] == "Car")
				{
					car.Refuel(double.Parse(commandTokens[2]));
				}
				else
				{
					truck.Refuel(double.Parse(commandTokens[2]));
				}
			}
		}

		Console.WriteLine(car.ToString());
		Console.WriteLine(truck.ToString());
	}
}