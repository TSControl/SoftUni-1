﻿public class Food : IFood
{
	public int Quantity { get; set; }
}