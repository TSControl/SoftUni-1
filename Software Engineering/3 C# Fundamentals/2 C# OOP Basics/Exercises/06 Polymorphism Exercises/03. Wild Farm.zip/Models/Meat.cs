﻿public class Meat : Food
{

}