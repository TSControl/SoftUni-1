﻿public class Owl : Bird
{
	public Owl(string name, double weight, double wingSize)
		:base(name, weight, wingSize)
	{

	}

	public override string AskFood()
	{
		return "Hoot Hoot";
	}
}