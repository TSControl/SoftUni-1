﻿public class Vegetable : Food
{

}