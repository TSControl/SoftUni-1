﻿public class Seeds : Food
{

}