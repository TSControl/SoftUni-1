﻿using System;
using System.Collections.Generic;

public class Animal : IAnimal
{
	public string Name { get; set; }
	
	public double Weight { get; set; }
	
	public int FoodEaten { get; set; }

	public virtual string AskFood()
	{
		return "";
	}

	public void TryEat(string food, List<string> allowedFoodTypes, double foodMultiplier)
	{
		var foodTokens = food.Split();
		var foodType = foodTokens[0];
		var foodQuantity = int.Parse(foodTokens[1]);

		if (allowedFoodTypes.Contains(foodType))
		{
			this.FoodEaten += foodQuantity;
			this.Weight += foodQuantity * foodMultiplier;
		}
		else
		{
			Console.WriteLine($"{this.GetType().Name} does not eat {foodType}!");
		}
	}
}