﻿public class Fruit : Food
{

}