﻿using System;
using System.Collections.Generic;

class StartUp
{
	static void Main()
	{
		const double HEN_FOOD_WEIGHT_MULTIPLIER = 0.35;
		const double OWL_FOOD_WEIGHT_MULTIPLIER = 0.25;
		const double MOUSE_FOOD_WEIGHT_MULTIPLIER = 0.10;
		const double CAT_FOOD_WEIGHT_MULTIPLIER = 0.30;
		const double DOG_FOOD_WEIGHT_MULTIPLIER = 0.40;
		const double TIGER_FOOD_WEIGHT_MULTIPLIER = 1.00;

		var allowedFoodTypesHen = new List<string>()
			{
				"Vegetable",
				"Fruit",
				"Meat",
				"Seeds"
			};

		var allowedFoodTypesMouse = new List<string>()
			{
				"Vegetable",
				"Fruit"
			};

		var allowedFoodTypesCat = new List<string>()
			{
				"Vegetable",
				"Meat"
			};

		var allowedFoodTypesTigersDogsOwls = new List<string>()
			{
				"Meat"
			};

		var animals = new List<Animal>();
		string line;

		while ((line = Console.ReadLine()) != "End")
		{
			var animalTokens = line.Split();
			var food = Console.ReadLine();

			var animalType = animalTokens[0];

			switch (animalType)
			{
				case "Owl":
					var owl = new Owl(animalTokens[1], double.Parse(animalTokens[2]), double.Parse(animalTokens[3]));
					Console.WriteLine(owl.AskFood());
					owl.TryEat(food, allowedFoodTypesTigersDogsOwls, OWL_FOOD_WEIGHT_MULTIPLIER);
					animals.Add(owl);
					break;
				case "Hen":
					var hen = new Hen(animalTokens[1], double.Parse(animalTokens[2]), double.Parse(animalTokens[3]));
					Console.WriteLine(hen.AskFood());
					hen.TryEat(food, allowedFoodTypesHen, HEN_FOOD_WEIGHT_MULTIPLIER);
					animals.Add(hen);
					break;
				case "Mouse":
					var mouse = new Mouse(animalTokens[1], double.Parse(animalTokens[2]), animalTokens[3]);
					Console.WriteLine(mouse.AskFood());
					mouse.TryEat(food, allowedFoodTypesMouse, MOUSE_FOOD_WEIGHT_MULTIPLIER);
					animals.Add(mouse);
					break;
				case "Dog":
					var dog = new Dog(animalTokens[1], double.Parse(animalTokens[2]), animalTokens[3]);
					Console.WriteLine(dog.AskFood());
					dog.TryEat(food, allowedFoodTypesTigersDogsOwls, DOG_FOOD_WEIGHT_MULTIPLIER);
					animals.Add(dog);
					break;
				case "Cat":
					var cat = new Cat(animalTokens[1], double.Parse(animalTokens[2]), animalTokens[3], animalTokens[4]);
					Console.WriteLine(cat.AskFood());
					cat.TryEat(food, allowedFoodTypesCat, CAT_FOOD_WEIGHT_MULTIPLIER);
					animals.Add(cat);
					break;
				case "Tiger":
					var tiger = new Tiger(animalTokens[1], double.Parse(animalTokens[2]), animalTokens[3], animalTokens[4]);
					Console.WriteLine(tiger.AskFood());
					tiger.TryEat(food, allowedFoodTypesTigersDogsOwls, TIGER_FOOD_WEIGHT_MULTIPLIER);
					animals.Add(tiger);
					break;
			}
		}

		animals.ForEach(a => Console.WriteLine(a.ToString()));
	}
}