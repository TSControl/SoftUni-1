﻿using System;

public class Rectangle : Shape
{
    private double height;
    private double width;

    public Rectangle(double height, double width)
    {
        this.Height = height;
        this.Width = width;
    }

    public double Height
    {
		get { return height; }
        set
		{
			if (value <= 0)
			{
				throw new ArgumentOutOfRangeException(nameof(this.Height), "Height must be non-zero and positive");
			}
			height = value;
		}
    }

    public double Width
    {
        get { return width; }
		set
		{
			if (value <= 0)
			{
				throw new ArgumentOutOfRangeException(nameof(this.Width), "Width must be non-zero and positive");
			}
			width = value;
		}
	}

    public override double CalculatePerimeter()
    {
        double result = 2 * (this.Width + this.Height);
        return result;
    }

    public override double CalculateArea()
    {
        double result = this.Width * this.Height;
        return result;
    }

    public override string Draw()
    {
        return base.Draw() + "Rectangle";
    }
}