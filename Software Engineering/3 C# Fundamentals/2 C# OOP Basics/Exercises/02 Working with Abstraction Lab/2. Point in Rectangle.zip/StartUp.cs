﻿using System;
using System.Linq;

class StartUp
{
    static void Main(string[] args)
    {
        var recCor = Console.ReadLine().Split().Select(int.Parse).ToArray();

        var bottomLeftX = recCor[0];
        var bottomLeftY = recCor[1];
        var bottomLeftPoint = new Point(bottomLeftX, bottomLeftY);

        var topRightX = recCor[2];
        var topRightY = recCor[3];
        var topRightPoint = new Point(topRightX, topRightY);

        var rectangle = new Rectangle(bottomLeftPoint, topRightPoint);

        var n = int.Parse(Console.ReadLine());
        for (int i = 0; i < n; i++)
        {
            var coordinates = Console.ReadLine().Split().Select(int.Parse).ToArray();
            var x = coordinates[0];
            var y = coordinates[1];
            var point = new Point(x, y);
            var isInside = rectangle.Contains(point);
            Console.WriteLine(isInside);
        }
    }
}