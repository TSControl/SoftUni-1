﻿public class Rectangle
{
    public Point TopRight { get; set; }
    public Point BottomLeft { get; set; }

    public Rectangle(Point bottomLeft, Point topRight)
    {
        this.TopRight = topRight;
        this.BottomLeft = bottomLeft;
    }

    public bool Contains(Point point)
    {
        if (point.X >= this.BottomLeft.X
            && point.X <= this.TopRight.X
            && point.Y <= this.TopRight.Y
            && point.Y >= this.BottomLeft.Y)
        {
            return true;
        }
        return false;
    }
}