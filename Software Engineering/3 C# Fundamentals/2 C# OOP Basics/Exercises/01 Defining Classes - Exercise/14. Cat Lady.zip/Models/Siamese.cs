﻿namespace Problem0.Models
{
    public class Siamese : Cat
    {
        public int EarSize { get; set; }

        public Siamese(string name, int earSize)
        {
            this.Name = name;
            this.EarSize = earSize;
        }

        public override string ToString()
        {
            return $"{this.GetType().Name} {this.Name} {this.EarSize}";
        }
    }
}
