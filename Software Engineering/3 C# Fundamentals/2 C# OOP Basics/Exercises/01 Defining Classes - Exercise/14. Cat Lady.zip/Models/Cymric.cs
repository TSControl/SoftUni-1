﻿namespace Problem0.Models
{
    public class Cymric : Cat
    {
        public double FurLength { get; set; }

        public Cymric(string name, double furLength)
        {
            this.Name = name;
            this.FurLength = furLength;
        }

        public override string ToString()
        {
            return $"{this.GetType().Name} {this.Name} {this.FurLength:F2}";
        }
    }
}
