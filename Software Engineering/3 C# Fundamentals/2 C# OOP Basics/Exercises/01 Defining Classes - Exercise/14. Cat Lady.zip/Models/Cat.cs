﻿namespace Problem0.Models
{
    public class Cat
    {
        public string Name { get; set; }
    }
}
