﻿namespace Problem0.Models
{
    public class StreetExtraordinaire : Cat
    {
        public int DecibelsOfMeows { get; set; }

        public StreetExtraordinaire(string name, int decibels)
        {
            this.Name = name;
            this.DecibelsOfMeows = decibels;
        }

        public override string ToString()
        {
            return $"{this.GetType().Name} {this.Name} {this.DecibelsOfMeows}";
        }
    }
}
