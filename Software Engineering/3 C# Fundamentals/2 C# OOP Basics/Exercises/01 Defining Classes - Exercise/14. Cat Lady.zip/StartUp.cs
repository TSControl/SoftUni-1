﻿namespace Problem0
{
    using Problem0.Models;
    using System;
    using System.Collections.Generic;
    using System.Linq;

    class StartUp
    {
        static void Main(string[] args)
        {
            var cats = new List<Cat>();

            string line;
            while ((line = Console.ReadLine().Trim()) != "End")
            {
                var catTokens = line.Split();
                var catType = catTokens[0];
                var catName = catTokens[1];
                var catInfo = catTokens[2];

                switch (catType)
                {
                    case "StreetExtraordinaire":
                        var streetCat = new StreetExtraordinaire(catName, int.Parse(catInfo));
                        cats.Add(streetCat);
                        break;
                    case "Siamese":
                        var siameseCat = new Siamese(catName, int.Parse(catInfo));
                        cats.Add(siameseCat);
                        break;
                    case "Cymric":
                        var cymricCat = new Cymric(catName, double.Parse(catInfo));
                        cats.Add(cymricCat);
                        break;
                }
            }

            var nameOfCatToPrint = Console.ReadLine();
            var catToPrint = cats.FirstOrDefault(c => c.Name == nameOfCatToPrint);
            Console.WriteLine(catToPrint.ToString());
        }
    }
}
