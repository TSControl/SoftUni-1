﻿namespace Problem0
{
    using Problem0.Models;
    using System;

    class StartUp
    {
        static void Main(string[] args)
        {
            var figureType = Console.ReadLine();
            var width = int.Parse(Console.ReadLine());

            switch (figureType)
            {
                case "Square":
                    var square = new Rectangle(width, width);
                    var squareDrawingTool = new DrawingTool(square);
                    squareDrawingTool.Draw();
                    break;
                case "Rectangle":
                    var height = int.Parse(Console.ReadLine());
                    var rectangle = new Rectangle(width, height);
                    var rectangleDrawingTool = new DrawingTool(rectangle);
                    rectangleDrawingTool.Draw();
                    break;
            }
        }
    }
}