﻿namespace Problem0.Models
{
    using System;
    using System.Text;

    public class DrawingTool
    {
        public int Width { get; set; }
        public int Height { get; set; }

        public DrawingTool(Rectangle rectangle)
        {
            this.Width = rectangle.Width;
            this.Height = rectangle.Height;
        }

        public void Draw()
        {
            var builder = new StringBuilder();
            builder.Append('|');
            builder.Append(new string('-', this.Width));
            builder.Append('|');
            builder.AppendLine();

            for (int i = 0; i < this.Height - 2; i++)
            {
                builder.Append('|');
                builder.Append(new string(' ', this.Width));
                builder.Append('|');
                builder.AppendLine();
            }

            builder.Append('|');
            builder.Append(new string('-', this.Width));
            builder.Append('|');
            builder.AppendLine();

            Console.WriteLine(builder.ToString());
        }
    }
}