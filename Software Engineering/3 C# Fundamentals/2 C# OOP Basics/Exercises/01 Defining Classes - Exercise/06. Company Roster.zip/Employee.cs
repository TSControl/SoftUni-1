﻿public class Employee
{
    private string name;
    private double salary;
    private string position;
    private string department;
    private string email = "n/a";
    private int age = -1;

    public string Name
    {
        get { return name; }
        set { name = value; }
    }

    public double Salary
    {
        get { return salary; }
        set { salary = value; }
    }

    public string Position
    {
        get { return position; }
        set { position = value; }
    }
    public string Department
    {
        get { return department; }
        set { department = value; }
    }
    public string Email
    {
        get { return email; }
        set { email = value; }
    }
    public int Age
    {
        get { return age; }
        set { age = value; }
    }

    public Employee(string name, double salary, string position, string department)
    {
        this.Salary = salary;
        this.Name = name;
        this.Position = position;
        this.Department = department;
        this.Age = -1;
        this.Email = "n/a";
    }

    public Employee(string name, double salary, string position, string department, string email)
        :this(name, salary, position, department)
    {
        this.Email = email;
        this.Age = -1;
    }

    public Employee(string name, double salary, string position, string department, int age)
        :this(name, salary, position, department)
    {
        this.Age = age;
        this.Email = "n/a";
    }

    public Employee(string name, double salary, string position, string department, string email, int age)
        :this(name, salary, position, department)
    {
        this.Email = email;
        this.Age = age;
    }
}