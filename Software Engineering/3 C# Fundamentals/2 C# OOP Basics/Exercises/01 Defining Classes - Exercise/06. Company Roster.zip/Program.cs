﻿using System;
using System.Collections.Generic;
using System.Linq;

class Program
{
    static void Main(string[] args)
    {
        var n = int.Parse(Console.ReadLine());
        var dic = new Dictionary<string, List<Employee>>();
        for (int i = 0; i < n; i++)
        {
            var tokens = Console.ReadLine().Split().ToArray();
            var name = tokens[0];
            var salary = double.Parse(tokens[1]);
            var position = tokens[2];
            var department = tokens[3];
            if (tokens.Length == 4)
            {

                var employee = new Employee(name, salary, position, department);
                if (!dic.ContainsKey(department))
                {
                    dic[department] = new List<Employee>();
                }
                dic[department].Add(employee);
            }
            else if (tokens.Length == 5)
            {
                int age;
                if (int.TryParse(tokens[4], out age))
                {
                    var employee = new Employee(name, salary, position, department, age);
                    if (!dic.ContainsKey(department))
                    {
                        dic[department] = new List<Employee>();
                    }
                    dic[department].Add(employee);
                }
                else
                {
                    var employee = new Employee(name, salary, position, department, tokens[4]);
                    if (!dic.ContainsKey(department))
                    {
                        dic[department] = new List<Employee>();
                    }
                        dic[department].Add(employee);
                }
            }
            else
            {
                var age = int.Parse(tokens[5]);
                var email = tokens[4];
                var employee = new Employee(name, salary, position, department, email, age);
                if (!dic.ContainsKey(department))
                {
                    dic[department] = new List<Employee>();
                }
                    dic[department].Add(employee);
            }
        }
        var richestDep = dic.OrderByDescending(kvp => kvp.Value.Average(e => e.Salary)).FirstOrDefault().Key;
        Console.WriteLine($"Highest Average Salary: {richestDep}");
        foreach (var employee in dic[richestDep].OrderByDescending(e => e.Salary))
        {
            Console.WriteLine($"{employee.Name} {employee.Salary:F2} {employee.Email} {employee.Age}");
        }
    }
}