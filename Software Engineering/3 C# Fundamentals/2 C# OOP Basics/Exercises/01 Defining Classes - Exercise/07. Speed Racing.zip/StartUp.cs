﻿using System;
using System.Collections.Generic;
using System.Linq;

class StartUp
{
    static void Main(string[] args)
    {
        var n = int.Parse(Console.ReadLine());
        var cars = new List<Car>();
        for (int i = 0; i < n; i++)
        {
            var carInfoTokens = Console.ReadLine().Split();
            var model = carInfoTokens[0];
            var fuelAmount = double.Parse(carInfoTokens[1]);
            var fuelConsumption = double.Parse(carInfoTokens[2]);
            var car = new Car(model, fuelAmount, fuelConsumption);
            cars.Add(car);
        }

        string command;
        while ((command = Console.ReadLine()) != "End")
        {
            var commandTokens = command.Split();
            var model = commandTokens[1];
            var amountOfKm = double.Parse(commandTokens[2]);
            var car = cars.FirstOrDefault(c => c.Model == model);
            try
            {
                car.TryMove(amountOfKm);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        cars.ForEach(c => Console.WriteLine($"{c.Model} {c.FuelAmount:F2} {c.DistanceTraveled:F0}"));
    }
}