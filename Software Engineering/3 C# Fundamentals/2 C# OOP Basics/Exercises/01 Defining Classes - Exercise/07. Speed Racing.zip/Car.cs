﻿using System;

public class Car
{
    private string model;
    private double fuelAmount;
    private double fuelConsumption;
    private double distanceTraveled;

    public Car(string model, double fuelAmount, double fuelConsumption)
    {
        this.Model = model;
        this.FuelAmount = fuelAmount;
        this.FuelConsumption = fuelConsumption;
        this.DistanceTraveled = 0;
    }

    public double DistanceTraveled
    {
        get { return distanceTraveled; }
        set { distanceTraveled = value; }
    }

    public double FuelConsumption
    {
        get { return fuelConsumption; }
        set { fuelConsumption = value; }
    }

    public double FuelAmount
    {
        get { return fuelAmount; }
        set { fuelAmount = value; }
    }

    public string Model
    {
        get { return model; }
        set { model = value; }
    }

    internal void TryMove(double amountOfKm)
    {
        if (FuelAmount >= amountOfKm * FuelConsumption)
        {
            FuelAmount -= amountOfKm * FuelConsumption;
            this.DistanceTraveled += amountOfKm;
        }
        else
        {
            throw new Exception("Insufficient fuel for the drive");
        }
    }
}