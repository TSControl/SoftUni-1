﻿using System;
using System.Collections.Generic;
using System.Linq;

class StartUp
{
    static void Main(string[] args)
    {
        var nums = Console.ReadLine().Split().Select(int.Parse).ToArray();
        var n = nums[0];
        var m = nums[1];
        var recs = new List<Rectangle>();

        for (int i = 0; i < n; i++)
        {
            var tokens = Console.ReadLine().Split();
            var id = tokens[0];
            var width = double.Parse(tokens[1]);
            var height = double.Parse(tokens[2]);
            var topLeftX = double.Parse(tokens[3]);
            var topLeftY = double.Parse(tokens[4]);
            var rec = new Rectangle(id, width, height, topLeftX, topLeftY);
            recs.Add(rec);
        }

        for (int i = 0; i < m; i++)
        {
            var tokens = Console.ReadLine().Split();
            var id1 = tokens[0];
            var id2 = tokens[1];
            var rec1 = recs.FirstOrDefault(r => r.Id == id1);
            var rec2 = recs.FirstOrDefault(r => r.Id == id2);
            Console.WriteLine(rec1.Intersects(rec2).ToString().ToLower());
        }
    }
}