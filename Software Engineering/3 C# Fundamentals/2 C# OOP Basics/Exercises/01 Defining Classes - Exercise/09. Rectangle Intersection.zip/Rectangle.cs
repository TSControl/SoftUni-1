﻿public class Rectangle
{
    public string Id { get; set; }
    public Point TopLeft { get; set; }
    public Point TopRight { get; set; }
    public Point BottomLeft { get; set; }
    public Point BottomRight { get; set; }

    public Rectangle(string id, double width, double height, double topLeftX, double topLeftY)
    {
        this.Id = id;
        this.TopLeft = new Point(topLeftX, topLeftY);
        this.TopRight = new Point(topLeftX + width, topLeftY);
        this.BottomLeft = new Point(topLeftX, topLeftY - height);
        this.BottomRight = new Point(topLeftX + width, topLeftY - height);
    }

    public bool Intersects(Rectangle rec)
    {
        if (rec.TopLeft.IsInsideRectangle(this) 
            || rec.TopRight.IsInsideRectangle(this) 
            || rec.BottomLeft.IsInsideRectangle(this) 
            || rec.BottomRight.IsInsideRectangle(this) 
            || this.TopLeft.IsInsideRectangle(rec)
            || this.TopRight.IsInsideRectangle(rec)
            || this.BottomLeft.IsInsideRectangle(rec)
            || this.BottomRight.IsInsideRectangle(rec))
        {
            return true;
        }
        return false;
    }
}