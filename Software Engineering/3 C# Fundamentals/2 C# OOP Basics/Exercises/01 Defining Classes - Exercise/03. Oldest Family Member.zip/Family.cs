﻿using System.Collections.Generic;
using System.Linq;

public class Family
{
    private List<Person> people;

    public List<Person> People
    {
        get { return people; }
        set { people = value; }
    }

    public Family()
    {
        this.People = new List<Person>();
    }

    public void AddMember (Person member)
    {
        this.People.Add(member);
    }

    public Person GetOldestMember()
    {
        return this.people.OrderByDescending(p => p.Age).FirstOrDefault();
    }
}