﻿namespace Problem1
{
    using Problem1.Models;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text.RegularExpressions;

    class StartUp
    {
        static void Main(string[] args)
        {
            var nameBirthday = new List<string>();
            var namename = new List<string>();
            var birthdayName = new List<string>();
            var birthdayBirthday = new List<string>();
            var people = new List<Person>();

            var firstInput = Console.ReadLine().Trim();

            string line;
            while ((line = Console.ReadLine().Trim()) != "End")
            {
                ParseLine(line, people, nameBirthday, namename, birthdayName, birthdayBirthday);
            }

            foreach (string nameNameInput in namename)
            {
                ParseNameName(nameNameInput, people);
            }

            foreach (string nameBirthdayInput in nameBirthday)
            {
                ParseNameBirthday(nameBirthdayInput, people);
            }

            foreach (string birthdayNameInput in birthdayName)
            {
                ParseBirthdayName(birthdayNameInput, people);
            }

            foreach (string birthdayBirthdayInput in birthdayBirthday)
            {
                ParseBirthdayBirthday(birthdayBirthdayInput, people);
            }

            var firstPerson = people.FirstOrDefault(p => p.Names == firstInput || p.Birthday == firstInput);
            Console.Write(firstPerson.ToString());
        }

        private static void ParseBirthdayBirthday(string birthdayBirthdayInput, List<Person> people)
        {
            var indexOfDash = birthdayBirthdayInput.IndexOf('-');
            var parentBirthday = birthdayBirthdayInput.Substring(0, indexOfDash - 1);
            var childBirthday = birthdayBirthdayInput.Substring(indexOfDash + 2);

            var parent = people.FirstOrDefault(p => p.Birthday == parentBirthday);
            var child = people.FirstOrDefault(p => p.Birthday == childBirthday);

            parent.Children.Add(child);
            child.Parents.Add(parent);
        }

        private static void ParseBirthdayName(string birthdayNameInput, List<Person> people)
        {
            var indexOfDash = birthdayNameInput.IndexOf('-');
            var parentBirthday = birthdayNameInput.Substring(0, indexOfDash - 1);
            var childNames = birthdayNameInput.Substring(indexOfDash + 2);

            var parent = people.FirstOrDefault(p => p.Birthday == parentBirthday);
            var child = people.FirstOrDefault(p => p.Names == childNames);

            parent.Children.Add(child);
            child.Parents.Add(parent);
        }

        private static void ParseNameBirthday(string nameBirthdayInput, List<Person> people)
        {
            var indexOfDash = nameBirthdayInput.IndexOf('-');
            var parentNames = nameBirthdayInput.Substring(0, indexOfDash - 1);
            var childBirthday = nameBirthdayInput.Substring(indexOfDash + 2);

            var parent = people.FirstOrDefault(p => p.Names == parentNames);
            var child = people.FirstOrDefault(p => p.Birthday == childBirthday);

            parent.Children.Add(child);
            child.Parents.Add(parent);
        }

        private static void ParseNameName(string nameNameInput, List<Person> people)
        {
            var indexOfDash = nameNameInput.IndexOf('-');
            var parentNames = nameNameInput.Substring(0, indexOfDash - 1);
            var childNames = nameNameInput.Substring(indexOfDash + 2);

            var parent = people.FirstOrDefault(p => p.Names == parentNames);
            var child = people.FirstOrDefault(p => p.Names == childNames);

            parent.Children.Add(child);
            child.Parents.Add(parent);
        }

        private static void ParseLine(string line, List<Person> people, List<string> nameBirthday, List<string> namename, List<string> birthdayName, List<string> birthdayBirthday)
        {
            if (Regex.IsMatch(line, @"(?<parentNames>\w+ \w+) - (?<childNames>\w+ \w+)"))
            {
                namename.Add(line);
            }
            else if (Regex.IsMatch(line, @"(?<parentNames>\w+ \w+) - (?<childBirthday>\d+\/\d+\/\d+)"))
            {
                nameBirthday.Add(line);
            }
            else if (Regex.IsMatch(line, @"(?<parentBirthday>\d+\/\d+\/\d+) - (?<childNames>\w+ \w+)"))
            {
                birthdayName.Add(line);
            }
            else if (Regex.IsMatch(line, @"(?<parentBirthday>\d+\/\d+\/\d+) - (?<childBirthday>\d+\/\d+\/\d+)"))
            {
                birthdayBirthday.Add(line);
            }
            else
            {
                var tokens = line.Split();
                var names = string.Concat(tokens[0] + " " + tokens[1]);
                var birthday = tokens[2];
                var person = new Person(names, birthday);
                people.Add(person);
            }
        }
    }
}
