﻿namespace Problem1.Models
{
    using System.Collections.Generic;
    using System.Text;

    public class Person
    {
        public string Names { get; set; }
        public string Birthday { get; set; }
        public List<Person> Parents { get; set; }
        public List<Person> Children { get; set; }

        public Person(string names, string birthday)
        {
            this.Names = names;
            this.Birthday = birthday;
            this.Parents = new List<Person>();
            this.Children = new List<Person>();
        }

        public override string ToString()
        {
            var builder = new StringBuilder();
            builder.AppendLine($"{this.Names} {this.Birthday}");
            builder.AppendLine("Parents:");
            
            foreach (var parent in this.Parents)
            {
                builder.AppendLine($"{parent.Names} {parent.Birthday}");
            }

            builder.AppendLine("Children:");

            foreach (var child in this.Children)
            {
                builder.AppendLine($"{child.Names} {child.Birthday}");
            }

            return builder.ToString();
        }
    }
}
