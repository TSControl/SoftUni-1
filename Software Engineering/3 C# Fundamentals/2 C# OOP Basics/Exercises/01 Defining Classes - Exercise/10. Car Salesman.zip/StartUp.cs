﻿using System;
using System.Collections.Generic;
using System.Linq;

class StartUp
{
    static void Main(string[] args)
    {
        var engines = new List<Engine>();
        var cars = new List<Car>();
        var n = int.Parse(Console.ReadLine());
        for (int i = 0; i < n; i++)
        {
            var engineParts = Console.ReadLine().Trim().Split();

            var engineModel = engineParts[0];
            var enginePower = int.Parse(engineParts[1]);

            if (engineParts.Length == 2)
            {
                var engine = new Engine(engineModel, enginePower);
                engines.Add(engine);
            }
            else if (engineParts.Length == 3)
            {
                if (int.TryParse(engineParts[2], out int engineDisplacement))
                {
                    var engine = new Engine(engineModel, enginePower, engineDisplacement);
                    engines.Add(engine);
                }
                else
                {
                    var engineEfficiency = engineParts[2];
                    var engine = new Engine(engineModel, enginePower, engineEfficiency);
                    engines.Add(engine);
                }
            }
            else if (engineParts.Length == 4)
            {
                var engineDisplacement = int.Parse(engineParts[2]);
                var engineEfficiency = engineParts[3];

                var engine = new Engine(engineModel, enginePower, engineDisplacement, engineEfficiency);
                engines.Add(engine);
            }
        }

        n = int.Parse(Console.ReadLine());
        for (int i = 0; i < n; i++)
        {
            var carParts = Console.ReadLine().Trim().Split();

            var carModel = carParts[0];
            var carEngineModel = carParts[1];
            var engine = engines.FirstOrDefault(e => e.Model == carEngineModel);

            if (carParts.Length == 2)
            {
                var car = new Car(carModel, carEngineModel);
                car.Engine = new Engine(engine.Model, engine.Power, engine.Displacement, engine.Efficiency);
                cars.Add(car);
            }
            else if (carParts.Length == 3)
            {
                if (int.TryParse(carParts[2], out int carWeight))
                {
                    var car = new Car(carModel, carEngineModel, carWeight);
                    car.Engine = new Engine(engine.Model, engine.Power, engine.Displacement, engine.Efficiency);
                    cars.Add(car);
                }
                else
                {
                    var carColor = carParts[2];
                    var car = new Car(carModel, carEngineModel, carColor);
                    car.Engine = new Engine(engine.Model, engine.Power, engine.Displacement, engine.Efficiency);
                    cars.Add(car);
                }
            }
            else if (carParts.Length == 4)
            {
                var carWeight = int.Parse(carParts[2]);
                var carColor = carParts[3];

                var car = new Car(carModel, carEngineModel, carWeight, carColor);
                car.Engine = new Engine(engine.Model, engine.Power, engine.Displacement, engine.Efficiency);
                cars.Add(car);
            }
        }

        //print
        foreach (var car in cars)
        {
            Console.WriteLine(car.ToString());
        }
    }
}