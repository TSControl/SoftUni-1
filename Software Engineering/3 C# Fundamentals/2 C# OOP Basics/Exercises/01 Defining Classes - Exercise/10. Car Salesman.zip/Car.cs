﻿using System.Text;

public class Car
{
    public string Model { get; set; }
    public string EngineModel { get; set; }
    public Engine Engine { get; set; }
    public double? Weight { get; set; }
    public string Color { get; set; }

    public Car(string model, string engineModel)
    {
        this.Model = model;
        this.EngineModel = engineModel;
    }

    public Car(string model, string engineModel, double? weight)
        : this(model, engineModel)
    {
        this.Weight = weight;
    }

    public Car(string model, string engineModel, string color)
    : this(model, engineModel)
    {
        this.Color = color;
    }

    public Car(string model, string engineModel, double? weight, string color)
    : this(model, engineModel)
    {
        this.Weight = weight;
        this.Color = color;
    }

    public override string ToString()
    {
        var builder = new StringBuilder();
        builder.Append($"{this.Model}:\n");
        builder.Append($"  {this.Engine.Model}:\n");
        builder.Append($"    Power: {Engine.Power}\n");

        if (Engine.Displacement != null)
            builder.Append($"    Displacement: {Engine.Displacement}\n");
        else
            builder.Append($"    Displacement: n/a\n");

        if (Engine.Efficiency != null)
            builder.Append($"    Efficiency: {Engine.Efficiency}\n");
        else
            builder.Append($"    Efficiency: n/a\n");

        if (this.Weight != null)
            builder.Append($"  Weight: {this.Weight}\n");
        else
            builder.Append($"  Weight: n/a\n");

        if (this.Color != null)
            builder.Append($"  Color: {this.Color}");
        else
            builder.Append($"  Color: n/a");

        return builder.ToString();
    }
}
