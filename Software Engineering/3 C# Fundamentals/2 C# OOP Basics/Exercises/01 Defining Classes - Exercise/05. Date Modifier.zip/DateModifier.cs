﻿using System;

public class DateModifier
{
    private string dateStr1;
    private string dateStr2;

    public string DateStr1
    {
        get { return dateStr1; }
        set { dateStr1 = value; }
    }

    public string DateStr2
    {
        get { return dateStr2; }
        set { dateStr2 = value; }
    }

    public DateModifier()
    {
    }

    public DateModifier(string dateStr1, string dateStr2)
    {
        this.DateStr1 = dateStr1;
        this.DateStr2 = dateStr2;
    }

    public int CalculateDiff()
    {
        var date1 = DateTime.Parse(this.DateStr1);
        var date2 = DateTime.Parse(this.DateStr2);
        return Math.Abs((date2 - date1).Days);
    }
}