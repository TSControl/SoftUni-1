﻿using System;

class Program
{
    static void Main(string[] args)
    {
        var dateStr1 = Console.ReadLine();
        var dateStr2 = Console.ReadLine();
        var dateModifier = new DateModifier(dateStr1, dateStr2);
        Console.WriteLine(dateModifier.CalculateDiff());
    }
}