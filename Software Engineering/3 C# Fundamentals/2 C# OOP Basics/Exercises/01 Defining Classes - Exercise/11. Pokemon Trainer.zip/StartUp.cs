﻿using System;
using System.Collections.Generic;
using System.Linq;

class StartUp
{
    static void Main(string[] args)
    {
        var trainers = new List<Trainer>();

        string line;
        while ((line = Console.ReadLine().Trim()) != "Tournament")
        {
            var lineSplit = line.Split();
            var trainerName = lineSplit[0];
            var pokemonName = lineSplit[1];
            var pokemonElement = lineSplit[2];
            var pokemonHealth = int.Parse(lineSplit[3]);

            if (!trainers.Any(t => t.Name == trainerName))
            {
                trainers.Add(new Trainer(trainerName));
            }

            var trainer = trainers.FirstOrDefault(t => t.Name == trainerName);

            var pokemon = new Pokemon(pokemonName, pokemonElement, pokemonHealth);

            trainer.Pokemons.Add(pokemon);
        }
        //after "Tournament"
        while ((line = Console.ReadLine().Trim()) != "End")
        {
            RemovePokemons(trainers, line);
        }

        //after "End"
        foreach (var trainer in trainers.OrderByDescending(t => t.BadgeCount))
        {
            Console.WriteLine($"{trainer.Name} {trainer.BadgeCount} {trainer.Pokemons.Count}");
        }

    }

    private static void RemovePokemons(List<Trainer> trainers, string line)
    {
        if (line.Equals("Fire"))
        {
            foreach (var trainer in trainers)
            {
                if (trainer.Pokemons.Any(p => p.Element == "Fire"))
                {
                    trainer.BadgeCount++;
                }
                else
                {
                    trainer.Pokemons.ForEach(p => p.Health -= 10);
                    for (int i = 0; i < trainer.Pokemons.Count; i++)
                    {
                        if (trainer.Pokemons[i].Health <= 0)
                        {
                            trainer.Pokemons.RemoveAt(i);
                            i++;
                        }
                    }
                }
            }
        }
        else if (line.Equals("Water"))
        {
            foreach (var trainer in trainers)
            {
                if (trainer.Pokemons.Any(p => p.Element == "Water"))
                {
                    trainer.BadgeCount++;
                }
                else
                {
                    trainer.Pokemons.ForEach(p => p.Health -= 10);
                    for (int i = 0; i < trainer.Pokemons.Count; i++)
                    {
                        if (trainer.Pokemons[i].Health <= 0)
                        {
                            trainer.Pokemons.RemoveAt(i);
                            i++;
                        }
                    }
                }
            }
        }
        else
        {
            foreach (var trainer in trainers)
            {
                if (trainer.Pokemons.Any(p => p.Element == "Electricity"))
                {
                    trainer.BadgeCount++;
                }
                else
                {
                    trainer.Pokemons.ForEach(p => p.Health -= 10);
                    for (int i = 0; i < trainer.Pokemons.Count; i++)
                    {
                        if (trainer.Pokemons[i].Health <= 0)
                        {
                            trainer.Pokemons.RemoveAt(i);
                            i++;
                        }
                    }
                }
            }
        }
    }
}
