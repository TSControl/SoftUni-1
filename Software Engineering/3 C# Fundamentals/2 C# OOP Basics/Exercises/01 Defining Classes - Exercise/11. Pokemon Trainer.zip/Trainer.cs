﻿using System.Collections.Generic;

public class Trainer
{
    public string Name { get; set; }
    public int BadgeCount { get; set; }
    public List<Pokemon> Pokemons { get; set; }

    public Trainer(string name)
    {
        this.Name = name;
        this.BadgeCount = 0;
        this.Pokemons = new List<Pokemon>();
    }
}