﻿using System;
using System.Collections.Generic;
using System.Text;

internal class Person
{
    public string Name { get; set; }
    public Company Company { get; set; }
    public List<Pokemon> Pokemons { get; set; }
    public List<Parent> Parents { get; set; }
    public List<Child> Children { get; set; }
    public Car Car { get; set; }

    public Person(string name)
    {
        this.Name = name;
        this.Pokemons = new List<Pokemon>();
        this.Parents = new List<Parent>();
        this.Children = new List<Child>();
    }

    public override string ToString()
    {
        var builder = new StringBuilder();
        builder.Append(Name + Environment.NewLine);

        builder.Append("Company:" + Environment.NewLine);
        if (this.Company != null)
            builder.Append(this.Company.ToString() + Environment.NewLine);

        builder.Append("Car:" + Environment.NewLine);
        if (this.Car != null)
            builder.Append(this.Car.ToString() + Environment.NewLine);

        builder.Append("Pokemon:" + Environment.NewLine);
        foreach (var pokemon in this.Pokemons)
        {
            builder.Append(pokemon.ToString() + Environment.NewLine);
        }

        builder.Append("Parents:" + Environment.NewLine);
        foreach (var parent in this.Parents)
        {
            builder.Append(parent.ToString() + Environment.NewLine);
        }

        builder.Append("Children:" + Environment.NewLine);
        foreach (var child in this.Children)
        {
            builder.Append(child.ToString() + Environment.NewLine);
        }

        return builder.ToString();
    }
}