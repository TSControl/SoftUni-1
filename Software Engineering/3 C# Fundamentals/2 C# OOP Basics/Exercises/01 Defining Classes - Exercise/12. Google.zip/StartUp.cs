﻿using System;
using System.Collections.Generic;
using System.Linq;

class StartUp
{
    static void Main(string[] args)
    {
        var people = new List<Person>();

        string line;
        while ((line = Console.ReadLine().Trim()) != "End")
        {
            var splitLine = line.Split();
            var name = splitLine[0];
            if (!people.Any(p => p.Name == name))
            {
                var personToAdd = new Person(name);
                people.Add(personToAdd);
            }
            var person = people.FirstOrDefault(p => p.Name == name);

            var keyWord = splitLine[1];
            if (keyWord.Equals("company"))
            {
                var companyName = splitLine[2];
                var department = splitLine[3];
                var salary = decimal.Parse(splitLine[4]);
                var company = new Company(companyName, department, salary);
                person.Company = company;
            }
            else if (keyWord.Equals("pokemon"))
            {
                var pokemonName = splitLine[2];
                var pokemonType = splitLine[3];
                var pokemon = new Pokemon(pokemonName, pokemonType);
                person.Pokemons.Add(pokemon); //chinging pokemons?
            }
            else if (keyWord.Equals("parents"))
            {
                var parentName = splitLine[2];
                var parentBirthday = splitLine[3];
                var parent = new Parent(parentName, parentBirthday);
                person.Parents.Add(parent);
            }
            else if (keyWord.Equals("children"))
            {
                var childName = splitLine[2];
                var childBirthday = splitLine[3];
                var child = new Child(childName, childBirthday);
                person.Children.Add(child);
            }
            else if (keyWord.Equals("car"))
            {
                var carModel = splitLine[2];
                var carSpeed = int.Parse(splitLine[3]);
                var car = new Car(carModel, carSpeed);
                person.Car = car;
            }
        }

        line = Console.ReadLine().Trim();
        var personToPrint = people.FirstOrDefault(p => p.Name == line);
        Console.WriteLine(personToPrint.ToString());
    }
}
