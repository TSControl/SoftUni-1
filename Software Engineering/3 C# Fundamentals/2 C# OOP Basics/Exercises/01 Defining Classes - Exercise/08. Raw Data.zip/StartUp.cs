﻿using System;
using System.Collections.Generic;
using System.Linq;

class StartUp
{
    static void Main(string[] args)
    {
        var n = int.Parse(Console.ReadLine());
        var cars = new List<Car>();

        for (int i = 0; i < n; i++)
        {
            var tokens = Console.ReadLine().Split();
            var model = tokens[0];
            var engineSpeed = int.Parse(tokens[1]);
            var enginePower = int.Parse(tokens[2]);
            var engine = new Engine(engineSpeed, enginePower);
            var cargoWeight = int.Parse(tokens[3]);
            var cargoType = tokens[4];
            var cargo = new Cargo(cargoWeight, cargoType);

            var tire1Pressure = double.Parse(tokens[5]);
            var tire1Age = int.Parse(tokens[6]);
            var tire1 = new Tire(tire1Pressure, tire1Age);

            var tire2Pressure = double.Parse(tokens[7]);
            var tire2Age = int.Parse(tokens[8]);
            var tire2 = new Tire(tire2Pressure, tire2Age);

            var tire3Pressure = double.Parse(tokens[9]);
            var tire3Age = int.Parse(tokens[10]);
            var tire3 = new Tire(tire3Pressure, tire3Age);

            var tire4Pressure = double.Parse(tokens[5]);
            var tire4Age = int.Parse(tokens[6]);
            var tire4 = new Tire(tire4Pressure, tire4Age);

            var tires = new List<Tire>() { tire1, tire2, tire3, tire4 };

            var car = new Car(model, engine, cargo, tires);
            cars.Add(car);
        }

        var command = Console.ReadLine();
        if (command == "fragile")
        {
            var sortedCars = cars.Where(c => c.Cargo.Type == "fragile" && c.Tires.Any(t => t.Pressure < 1.0)).ToList();
            sortedCars.ForEach(c => Console.WriteLine(c.Model));
        }
        else if (command == "flamable")
        {
            var sortedCars = cars.Where(c => c.Cargo.Type == "flamable" && c.Engine.Power > 250).ToList();
            sortedCars.ForEach(c => Console.WriteLine(c.Model));
        }
    }
}