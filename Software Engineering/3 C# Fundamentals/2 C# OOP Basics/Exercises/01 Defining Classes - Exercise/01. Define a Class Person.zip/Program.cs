﻿class Program
{
    static void Main(string[] args)
    {
        //var pesho = new Person("Pesho", 20);
        //var gosho = new Person { Name = "Gosho", Age = 18 };
        //var stamat = new Person("Stamat", 43);
    }
}