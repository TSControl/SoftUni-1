﻿using System;
using System.Collections.Generic;

class StartUp
{
	static void Main()
	{

	}
}