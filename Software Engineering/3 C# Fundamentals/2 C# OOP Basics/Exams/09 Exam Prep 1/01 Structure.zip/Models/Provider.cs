﻿using System;

public class Provider
{
	private string id;
	private double energyOutput;

	public Provider(string id, double energyOutput)
	{
		this.Id = id;
		this.EnergyOutput = energyOutput;
	}

	public string Id
	{
		get { return id; }
		private set { id = value; }
	}

	public double EnergyOutput
	{
		get { return energyOutput; }
		private set
		{
			if (value <= 0 || value >= 10000)
			{
				throw new ArgumentException("");
			}

			energyOutput = value;
		}
	}
}