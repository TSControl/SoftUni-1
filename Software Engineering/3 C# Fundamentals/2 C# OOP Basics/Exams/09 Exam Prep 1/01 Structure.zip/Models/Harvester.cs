﻿using System;

public class Harvester
{
	private string id;
	private double oreOutput;
	private double energyRequirement;

	public Harvester(string id, double oreOutput, double energyRequirement)
	{
		this.Id = id;
		this.OreOutput = oreOutput;
		this.EnergyRequirement = energyRequirement;
	}

	public string Id
	{
		get { return id; }
		private set { id = value; }
	}

	public double OreOutput
	{
		get { return oreOutput; }
		private set
		{
			if (value < 0)
			{
				throw new ArgumentException("");
			}

			oreOutput = value;
		}
	}

	public double EnergyRequirement
	{
		get { return energyRequirement; }
		private set
		{
			if (value < 0 || value > 20000)
			{
				throw new ArgumentException("");
			}

			energyRequirement = value;
		}
	}
}