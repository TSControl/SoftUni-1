﻿namespace StorageMaster.Models.Vehicles
{
	using StorageMaster.Exceptions;
	using StorageMaster.Models.Products;
	using System;
	using System.Collections.Generic;
	using System.Linq;

	public abstract class Vehicle
    {
		private List<Product> trunk;

		public Vehicle(int capacity)
		{
			this.Capacity = capacity;
			//this.Trunk = new List<Product>();//new Product[capacity]; //?
			this.trunk = new List<Product>(); //?
		}

		public int Capacity { get; }
		public IReadOnlyCollection<Product> Trunk { get => trunk.AsReadOnly(); } //?
		public bool IsFull { get => this.Trunk.Sum(p => p.Weight) >= this.Capacity; }
		public bool IsEmpty { get => !this.Trunk.Any(); }

		public void LoadProduct(Product product)
		{
			if (this.trunk.Count == this.Capacity)
			{
				throw new InvalidOperationException(CustomExceptions.LoadProduct);
			}

			this.trunk.Add(product);
		}

		public Product Unload()
		{
			if (this.trunk.Count == 0)
			{
				throw new InvalidOperationException(CustomExceptions.Unload);
			}

			var lastProduct = trunk.Last();

			trunk.RemoveAt(trunk.Count - 1); //?

			return lastProduct;
		}
	}
}
