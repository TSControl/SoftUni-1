﻿namespace StorageMaster.Controllers
{
	using global::StorageMaster.Factories;
	using global::StorageMaster.Models.Products;
	using global::StorageMaster.Models.Storages;
	using global::StorageMaster.Models.Vehicles;
	using System;
	using System.Collections.Generic;
	using System.Linq;

	public class StorageMaster
    {
		private List<Product> productPool;
		private List<Storage> storagePool;
		private ProductFactory productFactory;
		private StorageFactory storageFactory;
		private VehicleFactory vehicleFactory;
		private Vehicle currentVehicle;

		public StorageMaster()
		{
			this.productPool = new List<Product>();
			this.productFactory = new ProductFactory();
			this.storageFactory = new StorageFactory();
			this.vehicleFactory = new VehicleFactory();
		}

		public string AddProduct(string type, double price)
		{
			var product = productFactory.CreateProduct(type, price);

			productPool.Add(product);

			return $"Added {type} to pool";
		}

		public string RegisterStorage(string type, string name)
		{
			var storage = storageFactory.CreateStorage(type, name);

			storagePool.Add(storage);

			return $"Registered {name}";
		}

		public string SelectVehicle(string storageName, int garageSlot)
		{
			var storage = storagePool.FirstOrDefault(s => s.Name == storageName);

			//if (storage == null) //?
			//{
			//	throw new ArgumentException("NO TEXT PROVIDED... RANDOM GIBBERISH"); //???
			//}

			currentVehicle = storage.GetVehicle(garageSlot);

			return $"Selected {currentVehicle.GetType().Name}"; //right name?
		}

		public string LoadVehicle(IEnumerable<string> productNames)
		{
			int loadedProductsCount = 0;
			foreach (var productName in productNames)
			{
				var product = productPool.LastOrDefault(p => p.GetType().Name == productName); //right name?

				if (product == null)
				{
					throw new InvalidOperationException($"{productName} is out of stock!"); //I am too lazy to make method in CustomExceptions
				}

				var lastIndex = productPool.LastIndexOf(product); //

				currentVehicle.LoadProduct(product); //swapped order to avoid empty refference

				productPool.RemoveAt(lastIndex); //swapped order to avoid empty refference

				loadedProductsCount++;
			}

			return $"Loaded {loadedProductsCount}/{productNames.Count()} products into {currentVehicle.GetType().Name}";

		}

		public string SendVehicleTo(string sourceName, int sourceGarageSlot, string destinationName)
		{
			throw new NotImplementedException();
		}

		public string UnloadVehicle(string storageName, int garageSlot)
		{
			throw new NotImplementedException();
		}

		public string GetStorageStatus(string storageName)
		{
			throw new NotImplementedException();
		}

		public string GetSummary()
		{
			throw new NotImplementedException();
		}

	}
}
