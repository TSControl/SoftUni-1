﻿namespace StorageMaster.Exceptions
{
    public static class CustomExceptions
    {
		public static string Price { get => "Price cannot be negative!"; }
		public static string LoadProduct { get => "Vehicle is full!"; }
		public static string Unload { get => "No products left in vehicle!"; }
		public static string GetVehicleInvalidSlot { get => "Invalid garage slot!"; }
		public static string GetVehicleEmptySlot { get => "No vehicle in this garage slot!"; }
		public static string SendVehicleTo { get => "No room in garage!"; }
		public static string UnloadVehicle { get => "Storage is full!"; }
		public static string AddProduct { get => "Invalid product type!"; }
		public static string RegisterStorage { get => "Invalid storage type!"; }
		public static string CreateVehicle { get => "Invalid vehicle type!"; }
	}
}