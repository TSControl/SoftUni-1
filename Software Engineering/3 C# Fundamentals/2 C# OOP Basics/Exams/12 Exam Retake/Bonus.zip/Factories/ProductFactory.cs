﻿namespace StorageMaster.Factories
{
	using StorageMaster.Exceptions;
	using StorageMaster.Models.Products;
	using System;

	public class ProductFactory
    {
		public Product CreateProduct(string type, double price)
		{
			switch (type)
			{
				case "Gpu":
					return new Gpu(price);
				case "HardDrive":
					return new HardDrive(price);
				case "Ram":
					return new Ram(price);
				case "SolidStateDrive":
					return new SolidStateDrive(price);
				default:
					throw new InvalidOperationException(CustomExceptions.AddProduct);
			}
		}
    }
}
