﻿using StorageMaster.Exceptions;
using StorageMaster.Models.Products;
using StorageMaster.Models.Vehicles;
using System;
namespace StorageMaster.Models.Storages
{
	using System.Collections.Generic;
	using System.Linq;

	public abstract class Storage
    {
		public string Name { get; }
		public int Capacity { get; }
		public int GarageSlots { get; }
		public bool IsFull { get => true; } //
		private Vehicle[] garage;
		private List<Product> products;

		protected Storage(string name, int capacity, int garageSlots, IEnumerable<Vehicle> vehicles)
		{
			this.Name = name;
			this.Capacity = capacity;
			this.GarageSlots = garageSlots;
			this.garage = new Vehicle[garageSlots]; //?
			this.products = new List<Product>(); //?
		}

		public IReadOnlyCollection<Vehicle> Garage
		{
			get => this.garage; //.AsReadOnly() ???
		}


		public IReadOnlyCollection<Product> Products
		{
			get => this.products.AsReadOnly();
		}

		public Vehicle GetVehicle(int garageSlot)
		{
			if (garageSlot >= this.GarageSlots) //EQUAL or larger?
			{
				throw new InvalidOperationException(CustomExceptions.GetVehicleInvalidSlot);
			}

			if (garage[garageSlot] == null) //starting from 0? 
			{
				throw new InvalidOperationException(CustomExceptions.GetVehicleEmptySlot);
			}

			return garage[garageSlot]; //not neccessary to remove it too?
		}

		public int SendVehicleTo(int garageSlot, Storage deliveryLocation)
		{
			var vehicle = GetVehicle(garageSlot); //new Vechilce(oldVehicle) ?

			bool HasFreeGarageSlot = !deliveryLocation.IsFull;

			if (!HasFreeGarageSlot)
			{
				throw new InvalidOperationException(CustomExceptions.SendVehicleTo);
			}

			 var output = deliveryLocation.AddVehicle(vehicle); //was swapped with row below
			this.garage[garageSlot] = null; //this order? //this wont make vehicle null?
			return output;

		}

		public int UnloadVehicle(int garageSlot)
		{
			if (this.IsFull)
			{
				throw new InvalidOperationException(CustomExceptions.UnloadVehicle);
			}

			var vehicle = this.GetVehicle(garageSlot);

			int unloadedProductCount = 0;

			while (!vehicle.IsEmpty && this.Products.Sum(p => p.Weight) <= this.Capacity) //what if last space is less than product weight?
			{
				var product = vehicle.Unload();

				this.products.Add(product);

				unloadedProductCount++;
			}

			return unloadedProductCount;
		}

		public int AddVehicle(Vehicle vehicle) //bool?
		{
			//we should have already checked IsEmpty
			for (int i = 0; i < this.garage.Length; i++)
			{
				if (this.garage[i] == null)
				{
					this.garage[i] = vehicle;
					return i;
				}
			}

			return -1;
		}
	}
}
