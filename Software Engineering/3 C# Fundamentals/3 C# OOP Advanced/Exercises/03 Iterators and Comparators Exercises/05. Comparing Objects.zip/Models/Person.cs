﻿using System;

public class Person : IComparable<Person>
{
	public Person(string name, int age, string town)
	{
		this.Name = name;
		this.Age = age;
		this.Town = town;
	}
	public string Name { get; set; }
	public int Age { get; set; }
	public string Town { get; set; }

	public int CompareTo(Person other)
	{
		var comparedNames = this.Name.CompareTo(other.Name);
		var comparedAges = this.Age.CompareTo(other.Age);
		var comparedTowns = this.Town.CompareTo(other.Town);

		if (comparedNames == 0 && comparedAges == 0 && comparedTowns == 0)
		{
			return 0;
		}
		else if (comparedNames != 0)
		{
			return comparedNames;
		}
		else if (comparedAges != 0)
		{
			return comparedAges;
		}
		else //if (comparedTowns != 0)
		{
			return comparedTowns;
		}

		//return 0;
	}
}