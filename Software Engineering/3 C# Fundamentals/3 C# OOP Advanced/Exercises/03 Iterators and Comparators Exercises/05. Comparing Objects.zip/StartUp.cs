﻿using System;
using System.Collections.Generic;
using System.Linq;

class StartUp
{
	static void Main()
	{
		var people = new List<Person>();
		string line;

		while ((line = Console.ReadLine()) != "END")
		{
			var tokens = line.Split();
			var name = tokens[0];
			var age = int.Parse(tokens[1]);
			var town = tokens[2];

			var person = new Person(name, age, town);

			people.Add(person);
		}

		var n = int.Parse(Console.ReadLine()) - 1;
		var personN = people[n];

		var numberOfEqualPeople = people.Where(p => p.CompareTo(personN) == 0).Count();
		var numberOfNotEqualPeople = people.Where(p => p.CompareTo(personN) != 0).Count();
		var totalNumberOfPeople = people.Count();

		if (numberOfEqualPeople == 1)
		{
			Console.WriteLine("No matches");
		}
		else
		{
			Console.WriteLine($"{numberOfEqualPeople} {numberOfNotEqualPeople} {totalNumberOfPeople}");
		}
	}
}