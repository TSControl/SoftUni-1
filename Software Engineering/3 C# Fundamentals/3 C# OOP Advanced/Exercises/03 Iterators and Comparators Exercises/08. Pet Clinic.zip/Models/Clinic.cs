﻿using System;

public class Clinic //: IEnumerable<Pet>
{
	private Pet[] rooms;

	public Clinic(string name, int roomCount)
	{
		this.Name = name;

		ValidateRoomCount(roomCount);

		this.rooms = new Pet[roomCount];
	}

	public string Name { get; set; }
	private int MiddleIndex { get => this.rooms.Length / 2; }

	//public IEnumerator<Pet> GetEnumerator()
	//{
	//	var index = this.Center;
	//	yield return rooms[Center];
	//	for (int i = 1; i < (this.rooms.Length - 1) / 2; i++)
	//	{
	//		yield return rooms[this.Center - 1];
	//		yield return rooms[this.Center + 1];
	//	}
	//}

	//IEnumerator IEnumerable.GetEnumerator()
	//{
	//	return this.GetEnumerator();
	//}

	internal bool HasEmptyRooms()
	{
		for (int i = 0; i < this.rooms.Length; i++)
		{
			if (rooms[i] == null)
			{
				return true;
			}
		}

		return false;
	}

	public bool AddPet(Pet pet)
	{
		var currentIndex = this.MiddleIndex;
		if (rooms[currentIndex] == null)
		{
			rooms[currentIndex] = pet;
			return true;
		}

		//if (this.rooms.Length == 1)
		//{
		//	return false;
		//}

		for (int i = 1; i <= this.rooms.Length / 2; i++)
		{
			if (rooms[currentIndex - i] == null)
			{
				rooms[currentIndex - i] = pet;
				return true;
			}

			if (rooms[currentIndex + i] == null)
			{
				rooms[currentIndex + i] = pet;
				return true;
			}
		}

		return false;
	}

	public bool Release()
	{
		var currentIndex = this.MiddleIndex;

		if (rooms[currentIndex] != null)
		{
			rooms[currentIndex] = null;
			return true;
		}

		for (int i = 1; i < this.rooms.Length / 2; i++)
		{
			if (rooms[currentIndex + i] != null)
			{
				rooms[currentIndex + i] = null;
				return true;
			}
		}

		for (int i = 1; i < this.rooms.Length / 2; i++)
		{
			if (rooms[currentIndex - i] != null)
			{
				rooms[currentIndex - i] = null;
				return true;
			}
		}

		return false;
	}

	public void Print()
	{
		for (int i = 0; i < this.rooms.Length; i++)
		{
			if (rooms[i] == null)
			{
				Console.WriteLine("Room empty");
			}
			else
			{
				Console.WriteLine(rooms[i].ToString());
			}
		}
	}

	internal void PrintRoom(int roomIndex)
	{
		if (rooms[roomIndex] == null)
		{
			Console.WriteLine("Room empty");
		}
		else
		{
			Console.WriteLine(rooms[roomIndex].ToString());
		}
	}

	private void ValidateRoomCount(int roomCount)
	{
		if (roomCount % 2 == 0)
		{
			throw new InvalidOperationException("Invalid Operation!");
		}
	}
}