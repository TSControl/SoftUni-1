﻿using System;
using System.Collections.Generic;
using System.Linq;

class StartUp
{
	static void Main()
	{
		var pets = new List<Pet>();
		var clinics = new List<Clinic>();
		var n = int.Parse(Console.ReadLine());

		for (int i = 0; i < n; i++)
		{
			try
			{
				var splitCommand = Console.ReadLine().Split();
				var command = splitCommand[0];
				string clinicName;

				switch (command)
				{
					case "Create":
						string name = splitCommand[2];
						if (splitCommand[1] == "Pet")
						{
							pets.Add(new Pet(name, int.Parse(splitCommand[3]), splitCommand[4]));
						}
						else
						{
							clinics.Add(new Clinic(name, int.Parse(splitCommand[3])));
						}
						break;
					case "Add":
						var petName = splitCommand[1];
						clinicName = splitCommand[2];
						var pet = pets.FirstOrDefault(p => p.Name == petName);
						var clinic = clinics.FirstOrDefault(c => c.Name == clinicName);
						Console.WriteLine(clinic.AddPet(pet));
						break;
					case "Release":
						clinicName = splitCommand[1];
						var clinic2 = clinics.FirstOrDefault(c => c.Name == clinicName);
						Console.WriteLine(clinic2.Release());
						break;
					case "HasEmptyRooms":
						clinicName = splitCommand[1];
						var clinic1 = clinics.FirstOrDefault(c => c.Name == clinicName);
						Console.WriteLine(clinic1.HasEmptyRooms());
						break;
					case "Print":
						clinicName = splitCommand[1];
						var clinic4 = clinics.FirstOrDefault(c => c.Name == clinicName);
						if (splitCommand.Length == 2)
						{
							clinic4.Print();
						}
						else
						{
							var roomIndex = int.Parse(splitCommand[2]) - 1;
							clinic4.PrintRoom(roomIndex);
						}
						break;
				}
			}
			catch (Exception e)
			{
				Console.WriteLine(e.Message);
			}
		}
	}
}