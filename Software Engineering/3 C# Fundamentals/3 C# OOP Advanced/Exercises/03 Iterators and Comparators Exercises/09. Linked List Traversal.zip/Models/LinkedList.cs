﻿using System;
using System.Collections;
using System.Collections.Generic;

public class LinkedList<T> : IEnumerable<T>
	where T : IComparable<T>
{
	
	public class Node
	{
		public Node(T value)
		{
			this.Value = value;
		}

		public T Value { get; set; }

		public Node Next { get; set; }
	}

	public Node Head { get; private set; }
	public Node Tail { get; private set; }
	public int Count { get; private set; }

	public LinkedList()
	{
		this.Count = 0;
	}

	public void AddFirst(T item)
	{
		Node old = this.Head;

		this.Head = new Node(item);
		this.Head.Next = old;

		if (this.Count == 0)
		{
			Tail = Head;
		}

		this.Count++;
	}

	public void AddLast(T item)
	{
		Node old = this.Tail;

		this.Tail = new Node(item);

		if (this.Count == 0)
		{
			this.Head = this.Tail;
		}
		else
		{
			old.Next = this.Tail;
		}

		this.Count++;
	}
	public bool Remove(T element)
	{
		if (this.Count == 0)
		{
			return false;
			//throw new InvalidOperationException();
		}

		var current = this.Head;

		//var node = new Node(element);

		if (this.Head.Value.CompareTo(element) == 0)
		{
			this.Head = this.Head.Next;

			this.Count--;

			return true;
		}

		for (int i = 0; i < this.Count; i++)
		{
			if (current.Next.Value.CompareTo(element) == 0)
			{
				current.Next = current.Next.Next;

				current = current.Next;

				this.Count--;

				return true;
			}
		}

		return false;
	}

	public IEnumerator<T> GetEnumerator()
	{
		var tempElement = this.Head;
		while (tempElement != null)
		{
			yield return tempElement.Value;
			tempElement = tempElement.Next;
		}
	}

	IEnumerator IEnumerable.GetEnumerator()
	{
		return this.GetEnumerator();
	}
}