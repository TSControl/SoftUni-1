﻿using System;

class StartUp
{
	static void Main()
	{
		var list = new LinkedList<int>();

		var n = int.Parse(Console.ReadLine());

		for (int i = 0; i < n; i++)
		{
			try
			{
				var tokens = Console.ReadLine().Split();
				var command = tokens[0];
				var number = int.Parse(tokens[1]);
				switch (command)
				{
					case "Add":
						list.AddLast(number);
						break;
					case "Remove":
						list.Remove(number);
						break;
				}
			}
			catch (Exception e)
			{
				Console.WriteLine(e.Message);
			}
		}

		Console.WriteLine(list.Count);

		Console.WriteLine(string.Join(" ", list));

		//foreach (var element in list)
		//{
		//	Console.Write($"{element} ");
		//}

		Console.WriteLine();
	}
}