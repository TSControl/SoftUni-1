﻿using System;

public class Person : IComparable<Person>
{
	public Person(string name, int age)
	{
		this.Name = name;
		this.Age = age;
	}

	public string Name { get; set; }
	public int Age { get; set; }

	public override string ToString()
	{
		return $"{this.Name} {this.Age}";
	}

	public override bool Equals(Object other)
	{
		return (this.Name == ((Person)other).Name && this.Age == ((Person)other).Age);
	}

	public override int GetHashCode()
	{
		return this.Name.GetHashCode() + this.Age.GetHashCode();
	}

	public int CompareTo(Person other)
	{
		return this.GetHashCode().CompareTo(other.GetHashCode());
	}
}