﻿using System;
using System.Collections.Generic;
using System.Linq;

public class ListyIterator<T>
{
	private List<T> collection;
	private int currentIndex;

	public ListyIterator()
	{
		this.collection = new List<T>();
		this.currentIndex = 0;
	}

	public ListyIterator(ICollection<T> col)
	{
		this.collection = col.ToList();
		this.currentIndex = 0;
	}

	public bool Move()
	{
		bool hasNext = this.HasNext();

		if (hasNext)
			currentIndex++;

		return hasNext;
	}

	public bool HasNext()
	{
		if (this.currentIndex == this.collection.Count - 1)
			return false;
		else
		{
			return true;
		}
	}

	public void Print()
	{
		if (collection.Count == 0)
			throw new InvalidOperationException("Invalid Operation!");

		Console.WriteLine(this.collection[currentIndex]);
	}
}