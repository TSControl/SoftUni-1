﻿using System;
using System.Collections.Generic;
using System.Linq;

class StartUp
{
	static void Main()
	{
		string line;

		var listyList = new ListyIterator<string>();

		while ((line = Console.ReadLine()) != "END")
		{
			try
			{
				var splitLine = line.Split(" {}".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);

				var command = splitLine[0];


				switch (command)
				{
					case "Create":
						var collection = splitLine.Skip(1).ToArray();

						if (collection.Count() == 0)
						{
							listyList = new ListyIterator<string>();
						}
						else
							listyList = new ListyIterator<string>(collection);
						break;
					case "Move":
						Console.WriteLine(listyList.Move());
						break;
					case "Print":
						listyList.Print();
						break;
					case "HasNext":
						Console.WriteLine(listyList.HasNext());
						break;
					case "PrintAll":
						foreach (var element in listyList)
						{
							Console.Write(element + " ");
						}
						Console.WriteLine();
						break;
					default:
						continue;
				}
			}
			catch (Exception e)
			{
				Console.WriteLine(e.Message);
			}
		}
	}
}