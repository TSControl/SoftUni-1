﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

public class ListyIterator<T> : IEnumerable<T>
{
	private List<T> collection;
	private int currentIndex;

	public ListyIterator()
	{
		this.collection = new List<T>();
		this.currentIndex = 0;
	}

	public ListyIterator(ICollection<T> col)
	{
		this.collection = col.ToList();
		this.currentIndex = 0;
	}

	public bool Move()
	{
		bool hasNext = this.HasNext();

		if (hasNext)
			currentIndex++;

		return hasNext;
	}

	public bool HasNext()
	{
		if (this.currentIndex == this.collection.Count - 1)
			return false;
		else
		{
			return true;
		}
	}

	public void Print()
	{
		if (collection.Count == 0)
			throw new InvalidOperationException("Invalid Operation!");

		Console.WriteLine(this.collection[currentIndex]);
	}

	public IEnumerator<T> GetEnumerator()
	{
		for (int i = 0; i < this.collection.Count; i++)
		{
			yield return this.collection[i];
		}
	}

	IEnumerator IEnumerable.GetEnumerator()
	{
		return this.GetEnumerator();
	}
}