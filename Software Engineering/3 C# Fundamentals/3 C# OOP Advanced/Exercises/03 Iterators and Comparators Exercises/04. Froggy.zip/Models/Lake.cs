﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;

public class Lake : IEnumerable<int>
{
	private List<int> collection;

	public Lake(params int[] col)
	{
		this.collection = col.ToList();
	}

	public IEnumerator<int> GetEnumerator()
	{
		for (int i = 0; i < this.collection.Count; i += 2)
		{
			yield return collection[i];
		}

		for (int i = (collection.Count % 2 == 0) ? (collection.Count - 1) : (collection.Count - 2); i > 0; i -= 2)
		{
			yield return collection[i];
		}
	}

	IEnumerator IEnumerable.GetEnumerator()
	{
		return this.GetEnumerator();
	}
}