﻿using System;
using System.Linq;

class StartUp
{
	static void Main()
	{
		var nums = Console.ReadLine().Split(" ,".ToCharArray(), StringSplitOptions.RemoveEmptyEntries).Select(int.Parse).ToArray();

		var lake = new Lake(nums);

		Console.WriteLine(string.Join(", ", lake));
	}
}