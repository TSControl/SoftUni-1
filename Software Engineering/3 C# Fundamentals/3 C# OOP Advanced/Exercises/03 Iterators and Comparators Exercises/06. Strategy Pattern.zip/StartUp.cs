﻿using System;
using System.Collections.Generic;

class StartUp
{
	static void Main()
	{
		var people = new List<Person>();
		var n = int.Parse(Console.ReadLine());

		for (int i = 0; i < n; i++)
		{
			var tokens = Console.ReadLine().Split();
			var name = tokens[0];
			var age = int.Parse(tokens[1]);

			var person = new Person(name, age);

			people.Add(person);
		}

		var comparer1 = new PersonComparerOne();
		var comparer2 = new PersonComparerTwo();

		var set1 = new SortedSet<Person>(people, comparer1);
		var set2 = new SortedSet<Person>(people, comparer2);

		foreach (var person in set1)
		{
			Console.WriteLine(person);
		}

		foreach (var person in set2)
		{
			Console.WriteLine(person);
		}
	}
}