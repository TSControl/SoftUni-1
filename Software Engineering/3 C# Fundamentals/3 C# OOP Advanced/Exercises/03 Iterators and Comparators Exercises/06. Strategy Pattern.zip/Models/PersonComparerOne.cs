﻿using System.Collections.Generic;

public class PersonComparerOne : IComparer<Person>
{
	public int Compare(Person x, Person y)
	{
		var comparedNameLengths = x.Name.Length.CompareTo(y.Name.Length);

		if (comparedNameLengths != 0)
		{
			return comparedNameLengths;
		}
		else
		{
			var firstLetterCompared = x.Name[0].ToString().ToLower().CompareTo(y.Name[0].ToString().ToLower());

			return firstLetterCompared;
		}
	}
}
