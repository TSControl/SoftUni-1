﻿using System;
using System.Linq;

class StartUp
{
	static void Main()
	{
		string line;

		var stack = new CustomStack<string>();

		while ((line = Console.ReadLine()) != "END")
		{
			try
			{
				var splitLine = line.Split(" ,".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);

				var command = splitLine[0];


				switch (command)
				{
					case "Push":
						var collection = splitLine.Skip(1).ToArray();

						foreach (var str in collection)
						{
							stack.Push(str);
						}
						break;
					case "Pop":
						stack.Pop();
						break;
				}
			}
			catch (Exception e)
			{
				Console.WriteLine(e.Message);
			}
		}

		PrintCollection();
		PrintCollection();

		void PrintCollection()
		{
			foreach (var element in stack)
			{
				Console.WriteLine(element);
			}
		}
	}
}