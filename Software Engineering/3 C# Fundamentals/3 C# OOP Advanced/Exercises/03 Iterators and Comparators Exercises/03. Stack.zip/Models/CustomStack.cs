﻿using System;
using System.Collections;
using System.Collections.Generic;

public class CustomStack<T> : IEnumerable<T>
{
	private List<T> collection;

	public CustomStack()
	{
		this.collection = new List<T>();
	}

	private int LastIndex => this.collection.Count - 1;

	public void Push(T element)
	{
		collection.Insert(this.LastIndex + 1, element);
	}

	public T Pop()
	{
		ValidateIndex();

		T lastElement = collection[this.LastIndex];
		collection.RemoveAt(this.LastIndex);

		return lastElement;
	}

	public IEnumerator<T> GetEnumerator()
	{
		for (int i = LastIndex; i > -1; i--)
			yield return this.collection[i];
	}

	IEnumerator IEnumerable.GetEnumerator()
	{
		return this.GetEnumerator();
	}

	public void ValidateIndex()
	{
		if (this.LastIndex < 0)
			throw new Exception("No elements");
	}
}