﻿using System;

namespace ReflectionLab3
{
    class StartUp
    {
        static void Main(string[] args)
        {
			var spy = new Spy();
			string result = spy.RevealPrivateMethods("Hacker");
			Console.WriteLine(result);
        }
    }
}
