﻿using System;
using System.Linq;
using System.Reflection;
using System.Text;

public class Spy
{
	//public string StealFieldInfo(string className, params string[] fieldNames)
	//{
	//	Type type = Type.GetType(className);

	//	FieldInfo[] fields = type.GetFields(BindingFlags.Instance | BindingFlags.Static | BindingFlags.NonPublic | BindingFlags.Public);

	//	var builder = new StringBuilder();

	//	Object classInstance = Activator.CreateInstance(type, new object[] { });

	//	builder.AppendLine($"Class under investigation: {className}");

	//	foreach (FieldInfo field in fields.Where(f => fieldNames.Contains(f.Name)))
	//	{
	//		builder.AppendLine($"{field.Name} = {field.GetValue(classInstance)}");
	//	}

	//	return builder.ToString().Trim();
	//}

	//public string AnalyzeAccessModifiers(string className)
	//{
	//	Type type = Type.GetType(className);
	//	FieldInfo[] fields = type.GetFields(BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public);
	//	MethodInfo[] publicMethods = type.GetMethods(BindingFlags.Instance | BindingFlags.Public);
	//	MethodInfo[] nonPublicMethods = type.GetMethods(BindingFlags.Instance | BindingFlags.NonPublic);

	//	var builder = new StringBuilder();

	//	foreach (var field in fields)
	//	{
	//		builder.AppendLine($"{field.Name} must be private!");
	//	}


	//	foreach (var method in nonPublicMethods.Where(m => m.Name.StartsWith("get")))
	//	{
	//		builder.AppendLine($"{method.Name} have to be public!");
	//	}

	//	foreach (var method in publicMethods.Where(m => m.Name.StartsWith("set")))
	//	{
	//		builder.AppendLine($"{method.Name} have to be private!");
	//	}

	//	return builder.ToString().Trim();
	//}

	public string RevealPrivateMethods(string className)
	{
		Type type = Type.GetType(className);
		MethodInfo[] privateMethods = type.GetMethods(BindingFlags.Instance | BindingFlags.NonPublic);

		var builder = new StringBuilder();

		builder.AppendLine($"All Private Methods of Class: {className}");

		builder.AppendLine($"Base Class: {type.BaseType.Name}");

		foreach (var privateMethod in privateMethods)
		{
			builder.AppendLine($"{privateMethod.Name}");
		}


		return builder.ToString().Trim();
	}
}