﻿using System;
using System.Reflection;

public class Tracker
{
	public void PrintMethodsByAuthor()
	{
		var type = typeof(StartUp);

		var methods = type.GetMethods(BindingFlags.Instance | BindingFlags.Public | BindingFlags.Static);

		foreach (var method in methods)
		{
			foreach (SoftUniAttribute attribute in method.GetCustomAttributes<SoftUniAttribute>())
			{
				Console.WriteLine($"{method.Name} is written by {attribute.Name}");
			}
		}
		
	}
}