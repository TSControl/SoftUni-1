﻿using System;
using System.Collections.Generic;
using System.Linq;

class StartUp
{
	static void Main()
	{
		var n = int.Parse(Console.ReadLine());

		var boxList = new List<Box<string>>();

		for (int i = 0; i < n; i++)
		{
			var item = Console.ReadLine();

			var box = new Box<string>(item);
			boxList.Add(box);
		}

		var nums = Console.ReadLine().Split().Select(int.Parse).ToArray();
		var index1 = nums[0];
		var index2 = nums[1];

		SwapList(boxList, index1, index2);

		boxList.ForEach(b => Console.WriteLine(b.ToString()));
	}

	static void SwapList<T> (List<Box<T>> list, int index1, int index2)
	{
		var leftElement = list[index1];
		var rightElement = list[index2];

		list[index1] = rightElement;
		list[index2] = leftElement;
	}
}