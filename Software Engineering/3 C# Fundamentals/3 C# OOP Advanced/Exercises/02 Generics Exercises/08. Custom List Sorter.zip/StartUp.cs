﻿using System;

class StartUp
{
	static void Main()
	{
		var genericListOfStr = new GenericList<string>();
		var genericListOfDouble = new GenericList<double>();

		string line;

		while ((line = Console.ReadLine()) != "END")
		{
			var tokens = line.Split();

			switch (tokens[0])
			{
				case "Add":

					var element = tokens[1];
					double num;
					bool isNum = double.TryParse(element, out num);

					if (!isNum)
					{
						genericListOfStr.Add(element);
					}
					else
					{
						genericListOfDouble.Add(num);
					}

					break;

				case "Remove":

					var index = int.Parse(tokens[1]);

					if (genericListOfStr.Count() > 0)
					{
						genericListOfStr.Remove(index);
					}
					else
					{
						genericListOfDouble.Remove(index);
					}

					break;

				case "Contains":

					var element1 = tokens[1];
					double num1;
					bool isNum1 = double.TryParse(element1, out num1);

					if (!isNum1)
					{
						Console.WriteLine(genericListOfStr.Contains(element1));
					}
					else
					{
						Console.WriteLine(genericListOfDouble.Contains(num1));
					}

					break;

				case "Swap":

					var index1 = int.Parse(tokens[1]);
					var index2 = int.Parse(tokens[2]);

					if (genericListOfStr.Count() > 0)
					{
						genericListOfStr.Swap(index1, index2);
					}
					else
					{
						genericListOfDouble.Swap(index1, index2);
					}

					break;
				case "Greater":

					var element2 = tokens[1];
					
					//double num2;
					//bool isNum2 = double.TryParse(element2, out num2);

					//if (!isNum2)
					//{
						//Console.WriteLine(genericListOfStr.CountGreaterThan(element2));
					//}
					//else
					//{
					//	Console.WriteLine(genericListOfDouble.CountGreaterThan(num2));
					//}

					if (genericListOfStr.Count() > 0)
					{
						Console.WriteLine(genericListOfStr.CountGreaterThan(element2));
					}
					else
					{
						Console.WriteLine(genericListOfDouble.CountGreaterThan(element2));
					}

					break;
				case "Max":

					if (genericListOfStr.Count() > 0)
					{
						Console.WriteLine(genericListOfStr.Max());
					}
					else
					{
						Console.WriteLine(genericListOfDouble.Max());
					}

					break;
				case "Min":

					if (genericListOfStr.Count() > 0)
					{
						Console.WriteLine(genericListOfStr.Min());
					}
					else
					{
						Console.WriteLine(genericListOfDouble.Min());
					}

					break;

				case "Print":

					if (genericListOfStr.Count() > 0)
					{
						genericListOfStr.Print();
					}
					else
					{
						genericListOfDouble.Print();
					}

					break;

				case "Sort":


					if (genericListOfStr.Count() > 0)
					{
						Sorter<string>.Sort(genericListOfStr);
					}
					else
					{
						Sorter<double>.Sort(genericListOfDouble);
					}

					break;
			}
		}
	}
}