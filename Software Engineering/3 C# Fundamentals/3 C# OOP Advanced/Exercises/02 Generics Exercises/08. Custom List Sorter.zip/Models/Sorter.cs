﻿using System;

public class Sorter<T>
	where T : IComparable
{
	public static void Sort(GenericList<T> genericList)
	{
		genericList.Sort();
	}
}