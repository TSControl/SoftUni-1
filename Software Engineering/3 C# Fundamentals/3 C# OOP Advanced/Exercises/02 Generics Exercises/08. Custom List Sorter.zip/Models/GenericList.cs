﻿using System;
using System.Collections.Generic;
using System.Linq;

public class GenericList<T> : List<T>
		where T : IComparable
{
	private List<T> collection;

	public GenericList()
	{
		this.collection = new List<T>();
	}

	public void Add(T element)
	{
		this.collection.Add(element);
	}

	public T Remove(int index)
	{
		var element = this.collection[index];

		this.collection.RemoveAt(index);

		return element;
	}

	public bool Contains(T element)
	{
		if (this.collection.Contains(element))
		{
			return true;
		}

		return false;
	}

	public void Swap(int index1, int index2)
	{
		var leftElement = this.collection[index1];
		var rightElement = this.collection[index2];

		this.collection[index1] = rightElement;
		this.collection[index2] = leftElement;
	}

	public int CountGreaterThan(string element)
	{
		return this.collection.Where(e => (e.ToString()).CompareTo(element) > 0).Count();
	}

	public T Max()
	{
		return this.collection.Max();
	}

	public T Min()
	{
		return this.collection.Min();
	}

	public int Count()
	{
		return this.collection.Count;
	}

	public void Print()
	{
		this.collection.ForEach(e => Console.WriteLine(e));
	}

	public void Sort()
	{
		this.collection = this.collection.OrderBy(e => e).ToList();
	}
}