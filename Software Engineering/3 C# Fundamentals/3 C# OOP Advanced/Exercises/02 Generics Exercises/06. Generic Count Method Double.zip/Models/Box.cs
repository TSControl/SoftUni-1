﻿using System;

public class Box<T> : IBox
	where T : IComparable
{
	private T item;

	public Box(T item)
	{
		this.item = item;
	}

	public int CompareTo(T newItem)
	{
		//ToStrings added BECAUSE OF IDIOTIC TESTS SAYING THAT 3 > 11 !!!
		return ((this.item)).CompareTo(newItem);
	}

	public override string ToString()
	{
		return item.GetType().FullName + $": {item}";
	}
}