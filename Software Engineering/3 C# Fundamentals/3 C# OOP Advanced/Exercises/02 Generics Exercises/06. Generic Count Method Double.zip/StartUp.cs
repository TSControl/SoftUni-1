﻿using System;
using System.Collections.Generic;
using System.Linq;

class StartUp
{
	static void Main()
	{
		var n = int.Parse(Console.ReadLine());

		var boxList = new List<IBox>();

		for (int i = 0; i < n; i++)
		{
			var item = Console.ReadLine();

			double num = 0;

			var isDouble = double.TryParse(item, out num);

			if (isDouble)
			{
				var box = new Box<double>(num);
				boxList.Add(box);
			}
			else
			{
				var box = new Box<string>(item);
				boxList.Add(box);
			}
		}

		double elementNum = 0;

		var element = Console.ReadLine();

		var elementIsNum = double.TryParse(element, out elementNum);

		if (!elementIsNum)
		{
			Console.WriteLine(GetCountOfGreaterElements(boxList, element));
		}
		else
		{
			Console.WriteLine(GetCountOfGreaterElements(boxList, elementNum));
		}
	}

	static int GetCountOfGreaterElements<T>(List<IBox> list, T element)
		where T : IComparable
	{
		return list.Where(e => ((Box<T>)e).CompareTo(element) > 0).Count();
	}
}