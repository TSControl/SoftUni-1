﻿using System;

class StartUp
{
	static void Main()
	{
		var tokens1 = Console.ReadLine().Split();
		var names = tokens1[0] + " " + tokens1[1];
		var adress = tokens1[2];
		var town = tokens1[3];

		Console.WriteLine(new Threeuple<string, string, string> (names, adress, town));
		//
		var tokens2 = Console.ReadLine().Split();
		var name = tokens2[0];
		var litersOfBeer = int.Parse(tokens2[1]);
		var drunkOrNot = tokens2[2];
		bool isDrunk = true;

		if (drunkOrNot.StartsWith("not"))
			isDrunk = false;

		Console.WriteLine(new Threeuple<string, int, bool>(name, litersOfBeer, isDrunk));
		//
		var tokens3 = Console.ReadLine().Split();
		var name1 = tokens3[0];
		var accountBalance = double.Parse(tokens3[1]);
		var bankName = tokens3[2];

		Console.WriteLine(new Threeuple<string, double, string>(name1, accountBalance, bankName));
	}
}