﻿using System;

public interface IBox
{
	string ToString();
}