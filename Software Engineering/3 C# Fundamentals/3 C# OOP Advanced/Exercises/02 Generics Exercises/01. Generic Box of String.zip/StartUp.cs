﻿using System;

class StartUp
{
	static void Main()
	{
		var n = int.Parse(Console.ReadLine());

		for (int i = 0; i < n; i++)
		{
			var item = Console.ReadLine();
			int num = 0;
			var isInt = int.TryParse(item, out num);

			if (isInt)
			{
				var box = new Box<int>(num);
				Console.WriteLine(box.ToString());
			}
			else
			{
				var box = new Box<string>(item);
				Console.WriteLine(box.ToString());
			}
		}
	}
}