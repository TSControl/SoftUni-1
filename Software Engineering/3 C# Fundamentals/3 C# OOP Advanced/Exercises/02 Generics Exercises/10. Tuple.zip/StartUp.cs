﻿using System;

class StartUp
{
	static void Main()
	{
		var tokens1 = Console.ReadLine().Split();
		var names = tokens1[0] + " " + tokens1[1];
		var adress = tokens1[2];

		Console.WriteLine(new Tuple<string, string> (names, adress));
		//
		var tokens2 = Console.ReadLine().Split();
		var name = tokens2[0];
		var litersOfBeer = int.Parse(tokens2[1]);

		Console.WriteLine(new Tuple<string, int>(name, litersOfBeer));
		//
		var tokens3 = Console.ReadLine().Split();
		var integer = int.Parse(tokens3[0]);
		var doubleNum = double.Parse(tokens3[1]);

		Console.WriteLine(new Tuple<int, double>(integer, doubleNum));
	}
}