﻿public interface IBox
{
	string ToString();
}