﻿public class Box<T> : IBox
{
	private T item;

	public Box(T item)
	{
		this.item = item;
	}

	public override string ToString()
	{
		return item.GetType().FullName + $": {item}";
	}
}